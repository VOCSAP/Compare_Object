*&---------------------------------------------------------------------*
*& Programme       : Z_A_BC_POST_REFRESH_CHECK                         *
*& Description     : Comparaison d'objets en masse                     *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 10/06/2021                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

REPORT z_a_bc_compare_object.

" Include - Définition Types / Globales
INCLUDE z_a_bc_compare_object_top.

" Include - Ecran de sélection
INCLUDE z_a_bc_compare_object_sel.

" Include - Classe - Définition
INCLUDE z_a_bc_compare_object_c01.

" Include - Classe - Implémentation
INCLUDE z_a_bc_compare_object_c02.

" Include - Classe - Parallélisation
*INCLUDE z_a_bc_compare_object_cta.

" Include - Routine
INCLUDE z_a_bc_compare_object_f01.

***==================================================================***
**                           INITIALIZATION                           **
***==================================================================***
INITIALIZATION.
  " Initialisation
  go_main = lcl_main=>initialization( ).

***==================================================================***
**                         AT SELECTION-SCREEN                        **
***==================================================================***
AT SELECTION-SCREEN.


***==================================================================***
**                     AT SELECTION-SCREEN OUTPUT                     **
***==================================================================***
AT SELECTION-SCREEN OUTPUT.
  " Modification écran
  go_main->selection_screen_ouput( ).

***==================================================================***
**                         START-OF-SELECTION                         **
***==================================================================***
START-OF-SELECTION.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Traitement
  " -----------------------------------------------------------

  " Traitement principal
  go_main->start_of_selection( ).

END-OF-SELECTION.
