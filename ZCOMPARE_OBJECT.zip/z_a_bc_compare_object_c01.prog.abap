*&---------------------------------------------------------------------*
*&  Include           Z_A_BC_POST_REFRESH_CHECK_C01
*&---------------------------------------------------------------------*


*----------------------------------------------------------------------*
*       CLASS LCL_main DEFINIION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main DEFINITION FINAL CREATE PRIVATE.

*-- Publique
  PUBLIC SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Constructeur statique
    CLASS-METHODS class_constructor.

    " Initialisation
    CLASS-METHODS initialization
      RETURNING VALUE(ro_main) TYPE REF TO lcl_main.

    " Modification Ecran de sélection
    METHODS selection_screen_ouput.

    " Traitement
    METHODS start_of_selection
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Workbench - PBO
    METHODS status_2000.

    " Workbench - User Command
    METHODS user_command_2000.

    " Workbench - PBO
    METHODS status_3000.

    " Customizing - User Command
    METHODS user_command_3000.

    " Customizing - Lors du changement de ligne
    METHODS customizing_on_change_line
      IMPORTING
        !iv_row     TYPE int4 OPTIONAL
        !iv_tabname TYPE clike OPTIONAL
          PREFERRED PARAMETER !iv_tabname.

    " Appel transaction SE11
    METHODS ddic_transaction_display_table
      IMPORTING
        !iv_row TYPE int4.

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs

    " Constantes ID ALV
    CONSTANTS :
      BEGIN OF mc_salv_id,
        BEGIN OF customizing,
          table_list TYPE string VALUE 'CUSTO_TL',          "#EC NOTEXT
          origin     TYPE string VALUE 'CUSTO_OR',          "#EC NOTEXT
          target     TYPE string VALUE 'CUSTO_TA',          "#EC NOTEXT
        END OF  customizing,
        BEGIN OF workbench,
          result TYPE string VALUE 'WKB_RE',                "#EC NOTEXT
        END OF   workbench,
      END OF mc_salv_id.

    " Constantes Action Utilisateur
    CONSTANTS :
      BEGIN OF mc_ucomm,
        BEGIN OF common,
          exit  TYPE sy-ucomm VALUE 'EXIT',                 "#EC NOTEXT
          leave TYPE sy-ucomm VALUE 'LEAVE',                "#EC NOTEXT
          dummy TYPE sy-ucomm VALUE 'DUMMY',                "#EC NOTEXT
        END OF common,
        BEGIN OF customizing,
          next      TYPE sy-ucomm VALUE 'NEXT',             "#EC NOTEXT
          previous  TYPE sy-ucomm VALUE 'PREVIOUS',         "#EC NOTEXT
          read_more TYPE sy-ucomm VALUE 'READ_MORE',        "#EC NOTEXT
        END OF customizing,
        BEGIN OF workbench,
          save TYPE sy-ucomm VALUE 'SAVE',                  "#EC NOTEXT
        END OF workbench,
      END OF mc_ucomm.

*    CONSTANTS : mc_archive_type TYPE zed_archive_type VALUE 'OBJ_COMP'. "#EC NOTEXT

*-- Privée
  PRIVATE SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type
    TYPES :
      BEGIN OF ts_compare_title_box,
        origin        TYPE REF TO string,
        target        TYPE REF TO string,
        detail_origin TYPE REF TO string,
        detail_target TYPE REF TO string,
        lines_to_read TYPE REF TO sy-tabix,
      END OF   ts_compare_title_box.

    TYPES :
      BEGIN OF ts_selection_criteria_workb,
        ov_activ    TYPE REF TO xsdboolean,
        or_devclass LIKE REF TO s_pack[],
        or_obj_name LIKE REF TO s_progn[],
        or_funcname LIKE REF TO s_funcn[],
      END OF   ts_selection_criteria_workb.

    TYPES :
      BEGIN OF ts_selection_criteria_custo,
        ov_activ        TYPE REF TO xsdboolean,
        or_tabname      LIKE REF TO s_tabn[],
        ov_rowcount     TYPE REF TO soid-accnt,
        ov_partial_read TYPE REF TO xsdboolean,
      END OF   ts_selection_criteria_custo.

    TYPES :
      BEGIN OF ts_selection_criteria_system,
        ov_origin TYPE REF TO vers_dest-rfcdest,
        ov_target TYPE REF TO vers_dest-rfcdest,
      END OF   ts_selection_criteria_system.

    TYPES :
      BEGIN OF ts_selection_criteria_opt_comp,
        ov_all_type                 TYPE REF TO xsdboolean,
        ov_only_difference          TYPE REF TO xsdboolean,
        ov_only_object_commun       TYPE REF TO xsdboolean,
        ov_compare_identical_struct TYPE REF TO xsdboolean,
      END OF   ts_selection_criteria_opt_comp.

    TYPES :
      BEGIN OF ts_selection_criteria,
        system         TYPE lcl_main=>ts_selection_criteria_system,
        workbench      TYPE lcl_main=>ts_selection_criteria_workb,
        customizing    TYPE lcl_main=>ts_selection_criteria_custo,
        compare_option TYPE lcl_main=>ts_selection_criteria_opt_comp,
      END OF   ts_selection_criteria.

    TYPES :
      BEGIN OF ts_wa_object_workbench,
        t_devclass          TYPE btfr_package_tt,
        t_object_to_compare TYPE scwb_t_e071,
        t_only_origin       TYPE scwb_t_e071,
        t_only_target       TYPE scwb_t_e071,
      END OF   ts_wa_object_workbench.

    TYPES :
      BEGIN OF ts_wa_object_customizing,
        t_tabname_to_compare TYPE esh_t_om_tabname,
        t_tabname_origin     TYPE esh_t_om_tabname,
        t_tabname_target     TYPE esh_t_om_tabname,
      END OF   ts_wa_object_customizing.

    TYPES :
      BEGIN OF ts_work_area_object,
        workbench   TYPE lcl_main=>ts_wa_object_workbench,
        customizing TYPE lcl_main=>ts_wa_object_customizing,
      END OF   ts_work_area_object.

    TYPES :
      BEGIN OF ts_compare_customizing_com,
        display_icon               TYPE icon_d,
        tabname                    TYPE dd02l-tabname,
        lines_count_origin         TYPE sy-tabix,
        lines_count_target         TYPE sy-tabix,
        no_content_difference      TYPE xsdboolean,
        no_content_difference_icon TYPE icon_d,
        exist_in_origin            TYPE xsdboolean,
        exist_in_origin_icon       TYPE icon_d,
        exist_in_target            TYPE xsdboolean,
        exist_in_target_icon       TYPE icon_d,
        identical_structure        TYPE xsdboolean,
        identical_structure_icon   TYPE icon_d,
        no_common_fields           TYPE xsdboolean,
        no_common_fields_icon      TYPE icon_d,
        compare_error              TYPE xsdboolean,
        compare_error_icon         TYPE icon_d,
        message                    TYPE bapiret2-message,
      END OF   ts_compare_customizing_com.

    TYPES : tt_compare_customizing_com TYPE STANDARD TABLE OF ts_compare_customizing_com
                    WITH NON-UNIQUE KEY primary_key COMPONENTS tabname.

    TYPES :
      BEGIN OF ts_compare_workbench_result,
        id_result            TYPE sysuuid_c32,
        icon                 TYPE icon_d,
        object               TYPE tadir-object,
        obj_name             TYPE tadir-obj_name,
        exist_in_origin      TYPE xsdboolean,
        exist_in_origin_icon TYPE icon_d,
        exist_in_target      TYPE xsdboolean,
        exist_in_target_icon TYPE icon_d,
        fragment             TYPE vrs_compare_item-fragment,
        fragname             TYPE vrs_compare_item-fragname,
        package_origin       TYPE vrs_compare_item-devclass_a,
        package_target       TYPE vrs_compare_item-devclass_b,
        equal                TYPE vrs_compare_item-equal,
        equal_icon           TYPE icon_d,
        nonversionable       TYPE vrs_compare_item-nonversionable,
        nonversionable_icon  TYPE icon_d,
        not_readable         TYPE vrs_compare_item-not_readable,
        not_readable_icon    TYPE icon_d,
        not_comparable       TYPE vrs_compare_item-not_comparable,
        not_comparable_icon  TYPE icon_d,
        uname                TYPE sy-uname,
        timestamp            TYPE timestamp,
      END OF   ts_compare_workbench_result.

    TYPES : tt_compare_workbench_result TYPE STANDARD TABLE OF ts_compare_workbench_result
                    WITH NON-UNIQUE KEY primary_key COMPONENTS object obj_name fragment fragname.

    TYPES :
      BEGIN OF ts_component_descr,
        fieldname TYPE dd03vt-fieldname,
        scrtext_s TYPE dd03vt-scrtext_s,
        scrtext_m TYPE dd03vt-scrtext_m,
        scrtext_l TYPE dd03vt-scrtext_l,
      END OF   ts_component_descr.

    TYPES : tt_component_descr TYPE SORTED TABLE OF ts_component_descr
                    WITH NON-UNIQUE KEY primary_key COMPONENTS fieldname.
    TYPES :
      BEGIN OF ts_compare_customizing_result.
            INCLUDE TYPE : lcl_main=>ts_compare_customizing_com.
    TYPES :
      ot_content_origin  TYPE REF TO data,
      ot_content_target  TYPE REF TO data,
      t_component_origin TYPE cl_abap_structdescr=>component_table,
      t_component_target TYPE cl_abap_structdescr=>component_table,
      t_component_descr  TYPE lcl_main=>tt_component_descr,
      END OF   ts_compare_customizing_result.

    TYPES : tt_compare_customizing_result TYPE SORTED TABLE OF ts_compare_customizing_result
                    WITH NON-UNIQUE KEY primary_key COMPONENTS tabname.

    TYPES :
      BEGIN OF ts_compare_customizing_de_tab,
        o_salv          TYPE REF TO cl_salv_table,
        o_container     TYPE REF TO cl_gui_container,
        o_event_handler TYPE REF TO lcl_customizing_handle_events,
        current_tabname TYPE string,
        ot_display_data TYPE REF TO data,
      END OF   ts_compare_customizing_de_tab.

    TYPES :
      BEGIN OF ts_screen_3000_properties,
        btn_previous_active TYPE xsdboolean,
        btn_next_active     TYPE xsdboolean,
      END OF   ts_screen_3000_properties.

    TYPES :
      BEGIN OF ts_wa_compare_customizing,
        t_compare_result               TYPE lcl_main=>tt_compare_customizing_result,
        screen_properties              TYPE lcl_main=>ts_screen_3000_properties BOXED,
        display_element_table_list     TYPE lcl_main=>ts_compare_customizing_de_tab BOXED,
        display_element_content_origin TYPE lcl_main=>ts_compare_customizing_de_tab BOXED,
        display_element_content_target TYPE lcl_main=>ts_compare_customizing_de_tab BOXED,
      END OF   ts_wa_compare_customizing.

    TYPES :
      BEGIN OF ts_compare_wokbench_de_tab,
        o_salv          TYPE REF TO cl_salv_table,
        o_container     TYPE REF TO cl_gui_container,
        o_event_handler TYPE REF TO lcl_customizing_handle_events,
        t_display_data  TYPE lcl_main=>tt_compare_workbench_result,
      END OF   ts_compare_wokbench_de_tab.

    TYPES :
      BEGIN OF ts_wa_compare_workbench,
        t_compare_items TYPE vrs_compare_item_tab,
        s_rfcsi_origin  TYPE rfcsi,
        s_rfcsi_target  TYPE rfcsi,
        t_nonvers       TYPE scwb_t_e071,
        display_element TYPE lcl_main=>ts_compare_wokbench_de_tab,
      END OF   ts_wa_compare_workbench.

    TYPES :
      BEGIN OF ts_work_area_compare,
        system      TYPE lcl_main=>ts_compare_title_box BOXED,
        workbench   TYPE lcl_main=>ts_wa_compare_workbench BOXED,
        customizing TYPE lcl_main=>ts_wa_compare_customizing BOXED,
      END OF   ts_work_area_compare.

    TYPES :
      BEGIN OF ts_work_area_private,
        object  TYPE lcl_main=>ts_work_area_object,
        compare TYPE lcl_main=>ts_work_area_compare,
      END OF   ts_work_area_private.

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Progression
    CLASS-METHODS progress_display
      IMPORTING
        !iv_text       TYPE clike OPTIONAL
        !iv_msgid      TYPE sy-msgid OPTIONAL
        !iv_msgno      TYPE sy-msgno OPTIONAL
        !iv_msgv1      TYPE sy-msgv1 OPTIONAL
        !iv_msgv2      TYPE sy-msgv2 OPTIONAL
        !iv_msgv3      TYPE sy-msgv3 OPTIONAL
        !iv_msgv4      TYPE sy-msgv4 OPTIONAL
        !iv_percentage TYPE i.

    " Range To Where
    CLASS-METHODS range_2_where
      IMPORTING
        !ir_selopt_t        TYPE ANY TABLE
        !iv_tablename       TYPE clike OPTIONAL
        !iv_fieldname       TYPE clike
      RETURNING
        VALUE(rv_sql_where) TYPE string.

    " Affiche élément DDIC
    CLASS-METHODS _display_ddic_element
      IMPORTING
        !iv_obj_name TYPE clike
        !iv_obj_type TYPE clike.

    " Constructeur
    METHODS constructor.

    " Contrôle saisi
    METHODS _check_input
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Contrôle système
    METHODS _check_system
      IMPORTING
                !iv_rfcdest     TYPE rfcdest
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Récupération des données
    METHODS _object_get
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Récupération Objet Workbench
    METHODS _object_workbench_get
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Récupération Objet - Custo
    METHODS _object_customizing_get
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Récupération des objets des Packages
    METHODS _object_package_get
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Comparaison des objets
    METHODS _compare_object
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Comparaison des Ojets - Workbench
    METHODS _compare_object_workbench
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Comparaison des Ojets - Customizing
    METHODS _compare_object_customizing
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Comparaison des Tables - Customizing
    METHODS _customizing_compare_table
      IMPORTING
                !it_tabname_to_compare TYPE esh_t_om_tabname
                !iv_rowcount           TYPE sy-tabix OPTIONAL
      RETURNING VALUE(rv_subrc)        TYPE sy-subrc.

    " Comparaison - Affichage
    METHODS _compare_display
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Comparaison - Workbench - Affichage
    METHODS _compare_display_workbench
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Workbench - Résultat - Sauvegarde
    METHODS _workbench_result_save
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Comparaison - Customizing - Affichage
    METHODS _compare_display_customizing
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Initilisation Contenu Table - Customizing
    METHODS _custo_compare_content_table
      IMPORTING
        !iv_tablename     TYPE clike
        !it_data_origin   TYPE esh_t_co_rfcrt_data
        !it_data_target   TYPE esh_t_co_rfcrt_data
        !it_fields_origin TYPE esh_t_co_rfcrt_fields
        !it_fields_target TYPE esh_t_co_rfcrt_fields.

    " Constitution structure des tables - Comparaison
    METHODS _custo_compare_prepare_struct
      IMPORTING
        !it_fields_to_use       TYPE esh_t_co_rfcrt_fields
        !it_fields_to_compare   TYPE esh_t_co_rfcrt_fields OPTIONAL
        !iv_identical_structure TYPE xsdboolean OPTIONAL
      EXPORTING
        !et_component           TYPE cl_abap_structdescr=>component_table
      CHANGING
        !ct_component_descr     TYPE lcl_main=>tt_component_descr.

    " Création table dynamic
    METHODS _custo_compare_generate_table
      IMPORTING
                !it_component                 TYPE cl_abap_structdescr=>component_table
      EXPORTING
                !eot_table                    TYPE REF TO data
      RETURNING VALUE(rv_data_creation_error) TYPE xsdboolean.

    " Move-corresponding Table
    METHODS _custo_comp_content_table_set
      IMPORTING
        !it_fields        TYPE esh_t_co_rfcrt_fields
        !it_component     TYPE cl_abap_structdescr=>component_table
        !it_table_content TYPE STANDARD TABLE
      EXPORTING
        !et_data_export   TYPE STANDARD TABLE.

    " Customizing - Lecture de plus de données
    METHODS _custo_comp_content_read_more
      IMPORTING
                !iv_tabname     TYPE clike
                !iv_rowskip     TYPE sy-tabix OPTIONAL
                !iv_rowcount    TYPE sy-tabix
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Customizing - Initialisation affichage résultat comparaison
    METHODS _compare_display_feed_compare
      IMPORTING
                !iv_tabname     TYPE clike
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Customizing - Initialisation données d'affichage
    METHODS _custo_display_fill_content
      IMPORTING
        !it_content_to_use     TYPE STANDARD TABLE
        !it_content_to_compare TYPE STANDARD TABLE OPTIONAL
      EXPORTING
        !et_display_data       TYPE STANDARD TABLE.

    " Customizing - Initialisation ALV
    METHODS _custo_display_comp_alv_set
      IMPORTING
                !iv_origin          TYPE xsdboolean
                !it_component       TYPE cl_abap_structdescr=>component_table
                !it_component_descr TYPE lcl_main=>tt_component_descr
      RETURNING VALUE(rv_subrc)     TYPE sy-subrc.

    " Récupération nombre de lignes
    METHODS _rfc_table_lines_count
      IMPORTING
                !iv_tabname           TYPE dd02l-tabname
                !iv_destination       TYPE rfcdest
      EXPORTING
                !ev_subrc             TYPE sy-subrc
      RETURNING VALUE(rv_lines_count) TYPE sy-index.

    " Sélection à distance
    METHODS _rfc_read_table
      IMPORTING
                !iv_rowcount    TYPE soid-accnt OPTIONAL
                !iv_rowskip     TYPE soid-accnt OPTIONAL
                !iv_destination TYPE rfcdest
                !iv_query_table TYPE dd02l-tabname
                !it_fields      TYPE esh_t_co_rfcrt_fields OPTIONAL
                !it_options     TYPE esh_t_co_rfcrt_options OPTIONAL
      EXPORTING
                !et_data        TYPE STANDARD TABLE
                !et_fields      TYPE esh_t_co_rfcrt_fields
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs

    DATA : ms_work_area_private TYPE lcl_main=>ts_work_area_private.
    DATA : ms_selection_criteria TYPE lcl_main=>ts_selection_criteria.

ENDCLASS.             "lcl_main DEFINITION

*---------------------------------------------------------------------*
*       CLASS lcl_customizing_handle_events DEFINITION
*---------------------------------------------------------------------*
*
*---------------------------------------------------------------------*
CLASS lcl_customizing_handle_events DEFINITION.

*-- Publique
  PUBLIC SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Constructeur
    METHODS constructor
      IMPORTING
        !io_main       TYPE REF TO lcl_main
        !iv_salv_id    TYPE clike
        !io_salv_table TYPE REF TO cl_salv_table.

    " Handler - Lien
    METHODS on_link_click FOR EVENT link_click OF cl_salv_events_table
      IMPORTING !row !column.

    " Handler - Double clique
    METHODS on_double_click FOR EVENT double_click OF cl_salv_events_table
      IMPORTING !row !column.

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs

*-- Privée
  PRIVATE SECTION.

    " Handler - Lien - Custo Liste de table
    METHODS _on_link_click_custo_tl
      IMPORTING !iv_row    TYPE salv_de_row
                !iv_column TYPE salv_de_column.

    " Handler - Double-Clique - Custo Liste de table
    METHODS _on_double_click_custo_tl
      IMPORTING !iv_row    TYPE salv_de_row
                !iv_column TYPE salv_de_column.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

    DATA : mv_salv_id TYPE string.
    DATA : mo_main TYPE REF TO lcl_main.
    DATA : mo_salv_table TYPE REF TO cl_salv_table.

ENDCLASS.                    "lcl_customizing_handle_events DEFINITION
