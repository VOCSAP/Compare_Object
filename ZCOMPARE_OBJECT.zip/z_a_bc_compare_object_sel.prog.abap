*&---------------------------------------------------------------------*
*&  Include           Z_A_BC_POST_REFRESH_CHECK_SEL
*&---------------------------------------------------------------------*

***==================================================================***
**                         SELECTION-SCREEN                           **
***==================================================================***

" -----------------------------------------------------------
" Critère de sélection
" -----------------------------------------------------------

TABLES : tfdir, tadir, dd02l, e070.

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-tb1.
" -----------------------------------------------------------
" Système à comparer
" -----------------------------------------------------------

" Destination RFC - Origine
PARAMETERS : p_rfc_o TYPE vers_dest-rfcdest.

" Destination RFC - Cible
PARAMETERS : p_rfc_t TYPE vers_dest-rfcdest.

SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE text-tb2.
" -----------------------------------------------------------
" Objet à comparer
" -----------------------------------------------------------

" Workbench
PARAMETERS : p_workb RADIOBUTTON GROUP rg1 USER-COMMAND uc1 DEFAULT 'X'.

SELECTION-SCREEN BEGIN OF BLOCK b3 WITH FRAME TITLE text-tb3.
" -----------------------------------------------------------
" Objet à comparer - Workbench
" -----------------------------------------------------------

" Package
SELECT-OPTIONS : s_pack FOR tadir-devclass MODIF ID wkb.

*" Ordre
*SELECT-OPTIONS : s_trkorr FOR e070-trkorr MODIF ID wkb.

" Programme
SELECT-OPTIONS : s_progn FOR tadir-obj_name MODIF ID wkb.

" Module Fonction
SELECT-OPTIONS : s_funcn FOR tfdir-funcname MODIF ID wkb.

SELECTION-SCREEN END OF BLOCK b3.

" Customizing
PARAMETERS : p_custo RADIOBUTTON GROUP rg1.

SELECTION-SCREEN BEGIN OF BLOCK b4 WITH FRAME TITLE text-tb4.
" -----------------------------------------------------------
" Objet à comparer - Customizing
" -----------------------------------------------------------

" Table
SELECT-OPTIONS : s_tabn FOR dd02l-tabname NO INTERVALS MODIF ID cus.

SELECTION-SCREEN END OF BLOCK b4.

SELECTION-SCREEN END OF BLOCK b2.

SELECTION-SCREEN BEGIN OF BLOCK b5 WITH FRAME TITLE text-tb5.
" -----------------------------------------------------------
" Option de comparaison
" -----------------------------------------------------------

" Afficher uniquement différence
PARAMETERS : p_only_d AS CHECKBOX.

" Comparer uniquement objet commun
PARAMETERS : p_only_c AS CHECKBOX.

SELECTION-SCREEN BEGIN OF BLOCK b6 WITH FRAME TITLE text-tb6.

" Comparaison à structure identifuqe
PARAMETERS : p_siden AS CHECKBOX MODIF ID cus.

" Tout type de table
PARAMETERS : p_t_all AS CHECKBOX MODIF ID cus.

" Partionne la lecture
PARAMETERS : p_rpart AS CHECKBOX USER-COMMAND urp MODIF ID cus DEFAULT 'X'. "#EC NOTEXT

" Nombre de lignes
PARAMETERS : p_crowc TYPE soid-accnt DEFAULT gc_rowcount MODIF ID cus. "#EC NOTEXT

SELECTION-SCREEN END OF BLOCK b6.

SELECTION-SCREEN END OF BLOCK b5.
