*&---------------------------------------------------------------------*
*&  Include           Z_A_BC_POST_REFRESH_CHECK_C02
*&---------------------------------------------------------------------*


*----------------------------------------------------------------------*
*       CLASS LCL_main IMPLEMENTATION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main IMPLEMENTATION.

  METHOD class_constructor.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation Attributs Statique
    " -----------------------------------------------------------

  ENDMETHOD.

  METHOD initialization.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Création instance principale
    " -----------------------------------------------------------

    " Création instance principale
    CREATE OBJECT ro_main.

  ENDMETHOD.

  METHOD selection_screen_ouput.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Modification écran de sélection
    " -----------------------------------------------------------

    " Modification de l'écran
    LOOP AT SCREEN INTO DATA(ls_screen).

      " Suivant le groupe
      CASE ls_screen-group1.

        WHEN 'CUS'. ##NOTEXT
          " Customizing
          IF me->ms_selection_criteria-customizing-ov_activ->* EQ abap_false.
            " Custo non coché
            ""  --> Masque les éléments
            ls_screen-active    = 0.
            ls_screen-output    = 0.
            ls_screen-invisible = 1.

            ""  --> Réinitialise les données saisies
            REFRESH : s_tabn[].

          ELSE.
            " Custo coché
            "" --> Affiche les éléments
            ls_screen-active    = 1.
            ls_screen-output    = 1.
            ls_screen-invisible = 0.

          ENDIF.

          " Traitement spécifique à un élément
          CASE ls_screen-name.

            WHEN 'P_T_ALL'. ##NOTEXT
              " Critère figée
              ls_screen-input = 0.

            WHEN 'P_CROWC'.                                 "#EC NOTEXT
              " Lecture Partionnée (REad More)
              IF me->ms_selection_criteria-customizing-ov_partial_read->* EQ abap_false.
                " Lecture partiel désactivée
                ""  --> Empêche la saisie
                ls_screen-input = 0.
                CLEAR : me->ms_selection_criteria-customizing-ov_rowcount->*.

              ELSE.
                ""  --> Autorise la saisie
                ls_screen-input = 1.
                IF me->ms_selection_criteria-customizing-ov_rowcount->* IS INITIAL.
                  " Nombre de ligne vide
                  ""  --> Initialise nombre par défaut
                  me->ms_selection_criteria-customizing-ov_rowcount->* = gc_rowcount.

                ENDIF.

              ENDIF.

            WHEN OTHERS.
              "Autre

          ENDCASE.

        WHEN 'WKB'. ##NOTEXT
          " Workbench
          IF me->ms_selection_criteria-workbench-ov_activ->* EQ abap_false.
            " Workbench non coché
            ""  --> Masque les éléments
            ls_screen-active    = 0.
            ls_screen-output    = 0.
            ls_screen-invisible = 1.

            ""  --> Réinitialise les données saisies
            REFRESH : s_funcn[], s_progn[], s_pack[].

          ELSE.
            " Workbench coché
            "" --> Affiche les éléments
            ls_screen-active    = 1.
            ls_screen-output    = 1.
            ls_screen-invisible = 0.

          ENDIF.

        WHEN OTHERS.
          " Autre
          ""  --> Passe à l'itération suivante
          CONTINUE.

      ENDCASE.

      " Modification
      MODIFY screen FROM ls_screen.

    ENDLOOP.

  ENDMETHOD.

  METHOD constructor.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation attribut
    " -----------------------------------------------------------

    " Initialisation Critère de sélection - Système
    me->ms_selection_criteria-system-ov_origin = REF #( p_rfc_o ).
    me->ms_selection_criteria-system-ov_target = REF #( p_rfc_t ).

    " Initialisation Critère de sélection - Workbench
    me->ms_selection_criteria-workbench-ov_activ    = REF #( p_workb ).
    me->ms_selection_criteria-workbench-or_obj_name = REF #( s_progn[] ).
    me->ms_selection_criteria-workbench-or_devclass = REF #( s_pack[] ).
    me->ms_selection_criteria-workbench-or_funcname = REF #( s_funcn[] ).

    " Initialisation Critère de sélection - Customizing
    me->ms_selection_criteria-customizing-ov_activ        = REF #( p_custo ).
    me->ms_selection_criteria-customizing-or_tabname      = REF #( s_tabn[] ).
    me->ms_selection_criteria-customizing-ov_rowcount     = REF #( p_crowc ).
    me->ms_selection_criteria-customizing-ov_partial_read = REF #( p_rpart ).

    " Initialisation Critère de sélection - Option de Comparaison
    me->ms_selection_criteria-compare_option-ov_all_type                 = REF #( p_t_all ).
    me->ms_selection_criteria-compare_option-ov_only_difference          = REF #( p_only_d ).
    me->ms_selection_criteria-compare_option-ov_only_object_commun       = REF #( p_only_c ).
    me->ms_selection_criteria-compare_option-ov_compare_identical_struct = REF #( p_siden ).

    " Initialisation référence sur données globales
    me->ms_work_area_private-compare-system-origin        = REF #( gv_sytem_origin ).
    me->ms_work_area_private-compare-system-target        = REF #( gv_sytem_target ).
    me->ms_work_area_private-compare-system-detail_origin = REF #( gv_custo_det_origin ).
    me->ms_work_area_private-compare-system-detail_target = REF #( gv_custo_det_target ).
    me->ms_work_area_private-compare-system-lines_to_read = REF #( gv_lines_to_read_input ).

    " -----------------------------------------------------------
    " Modification valeur par défaut
    " -----------------------------------------------------------

    " Système source = Système en cours
    me->ms_selection_criteria-system-ov_origin->* = |{ sy-sysid }CLNT{ sy-mandt }|. "#EC NOTEXT

  ENDMETHOD.

  METHOD start_of_selection.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle saisie
    " -----------------------------------------------------------

    IF NOT me->_check_input( ) IS INITIAL.
      " Erreur
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Récupération des Objets
    " -----------------------------------------------------------

    " Récupération des Objets
    IF NOT me->_object_get( ) IS INITIAL.
      " Erreur
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    IF ( me->ms_selection_criteria-workbench-ov_activ->* EQ abap_true
      AND me->ms_work_area_private-object-workbench-t_object_to_compare[] IS INITIAL )
    OR ( me->ms_selection_criteria-customizing-ov_activ->* EQ abap_true
      AND me->ms_work_area_private-object-customizing-t_tabname_to_compare[] IS INITIAL ).
      " Aucun objet à comparer
      ""  --> Arrêt du traitement
      rv_subrc = 8.
      MESSAGE s244(5a) DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Comparaison des Objets
    " -----------------------------------------------------------

    IF NOT me->_compare_object( ) IS INITIAL.
      " Erreur
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Affichage résultat Comparaison
    " -----------------------------------------------------------

    IF NOT me->_compare_display( ) IS INITIAL.
      " Erreur
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

  ENDMETHOD.

  METHOD status_2000.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Préparation écran
    " -----------------------------------------------------------

    " Initialisation barre de statut
    SET PF-STATUS 'PF_STATUS_2000'.

    " Initialisation Barre de Titre
    SET TITLEBAR 'TITLEBAR_2000'.

    " -----------------------------------------------------------
    " Affichage ALV
    " -----------------------------------------------------------

    IF me->ms_work_area_private-compare-workbench-display_element-o_salv IS BOUND.
      me->ms_work_area_private-compare-workbench-display_element-o_salv->display( ).

    ENDIF.

  ENDMETHOD.

  METHOD user_command_2000.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Suivant l'Action utilisateur
    " -----------------------------------------------------------

    " Suivant l'action utilisateur
    CASE sy-ucomm.

      WHEN lcl_main=>mc_ucomm-common-exit.
        " Retour
        ""  --> Retour à l'écran précédent
        LEAVE TO SCREEN 0.

      WHEN lcl_main=>mc_ucomm-common-leave.
        " Quitter
        ""  --> Arrêt du programme
        LEAVE PROGRAM.

      WHEN lcl_main=>mc_ucomm-workbench-save.
        " Sauvegarde
        me->_workbench_result_save( ).

      WHEN OTHERS.
        " Autres

    ENDCASE.

  ENDMETHOD.

  METHOD status_3000.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_de_table_list     TYPE REF TO lcl_main=>ts_compare_customizing_de_tab,
      lo_de_content_target TYPE REF TO lcl_main=>ts_compare_customizing_de_tab,
      lo_de_content_origin TYPE REF TO lcl_main=>ts_compare_customizing_de_tab.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation éléments
    " -----------------------------------------------------------

    " Initialisation barre de statut
    SET PF-STATUS 'PF_STATUS_3000'.

    " Initialisation Barre de Titre
    SET TITLEBAR 'TITLEBAR_3000'.

    " -----------------------------------------------------------
    " Pré-Traitement
    " -----------------------------------------------------------

    " Initialisation raccourci syntaxique
    lo_de_table_list     = REF #( me->ms_work_area_private-compare-customizing-display_element_table_list ).
    lo_de_content_origin = REF #( me->ms_work_area_private-compare-customizing-display_element_content_origin ).
    lo_de_content_target = REF #( me->ms_work_area_private-compare-customizing-display_element_content_target ).

    " -----------------------------------------------------------
    " Affichage des ALV
    " -----------------------------------------------------------

    " Change le nom de la table
    gv_custo_tabname = lo_de_table_list->current_tabname.

    IF lo_de_table_list->o_salv IS BOUND.
      " Liste de Table - Affichage
      lo_de_table_list->o_salv->display( ).

    ENDIF.

    IF lo_de_content_origin->o_salv IS BOUND.
      " Affiche l'ALV données d'Origine
      lo_de_content_origin->o_salv->display( ).

    ENDIF.

    IF lo_de_content_target->o_salv IS BOUND.
      " Affiche l'ALV données Cible
      lo_de_content_target->o_salv->display( ).

    ENDIF.

    " -----------------------------------------------------------
    " Modification affichage
    " -----------------------------------------------------------

    " Parcours les éléments de l'écran
    LOOP AT SCREEN INTO DATA(ls_screen).

      " Suivant le groupe
      CASE ls_screen-group1.

        WHEN 'REM'. "#EC NOTEXT                                       "#EC NOTEXT "
          " REad More
          ""  --> Affiche / Masque l'option
          IF me->ms_selection_criteria-customizing-ov_partial_read->* EQ abap_true.
            " Lecture partiel activée
            ""  --> Affiche les éléments
            ls_screen-active    = 1.
            ls_screen-invisible = 0.

          ELSE.
            " Lecture partiel désactivée
            ""  --> Masque les éléments
            ls_screen-active    = 0.
            ls_screen-invisible = 1.

          ENDIF.

        WHEN 'BPR'.                                         "#EC NOTEXT
          " Groupe Bouton Précédent
          ""  --> Modification activation bouton précédent
          ls_screen-active = SWITCH #(
            me->ms_work_area_private-compare-customizing-screen_properties-btn_previous_active
            WHEN abap_true THEN 1
            ELSE 0
          ).

        WHEN 'BNE'.                                         "#EC NOTEXT
          " Groupe Bouton Suivant
          ""  --> Modification activation bouton suivant
          ls_screen-active = SWITCH #(
            me->ms_work_area_private-compare-customizing-screen_properties-btn_next_active
            WHEN abap_true THEN 1
            ELSE 0
          ).

        WHEN OTHERS.
          " Autre
          ""  --> Passe à l'itération suivante
          CONTINUE.

      ENDCASE.

      " Modifie l'affichage
      MODIFY screen FROM ls_screen.

    ENDLOOP.

  ENDMETHOD.

  METHOD user_command_3000.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
          lo_selections TYPE REF TO cl_salv_selections.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
    FIELD-SYMBOLS :
          <lfs_t_table_list> TYPE lcl_main=>tt_compare_customizing_com.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_tabix_tabname TYPE sy-tabix.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Suivant l'Action utilisateur
    " -----------------------------------------------------------

    " Suivant l'action utilisateur
    CASE sy-ucomm.

      WHEN lcl_main=>mc_ucomm-common-exit.
        " Retour
        ""  --> Retour à l'écran d'acceuil
        LEAVE TO SCREEN 0.

      WHEN lcl_main=>mc_ucomm-common-leave.
        " Quitter
        ""  --> Arrêt du programme
        LEAVE PROGRAM.

      WHEN lcl_main=>mc_ucomm-customizing-next
        OR lcl_main=>mc_ucomm-customizing-previous
        OR lcl_main=>mc_ucomm-customizing-read_more.
        " Entrée précedente // Suivante // Lire plus de lignes
        ""  --> Récupération Index actuellement sélectioné
        lo_selections = me->ms_work_area_private-compare-customizing-display_element_table_list-o_salv->get_selections( ).
        READ TABLE lo_selections->get_selected_rows( ) INDEX 1 INTO DATA(ls_selected_rows).
        IF ls_selected_rows IS INITIAL.
          " Aucune ligne sélectionnée
          ""  --> Arrêt du traitement
          RETURN.

        ENDIF.

        ""  --> Initialisation pointeur sur liste
        ASSIGN me->ms_work_area_private-compare-customizing-display_element_table_list-ot_display_data->*
            TO <lfs_t_table_list>.
        IF sy-subrc NE 0.
          " Erreur initialisation pointeur
          ""  --> Arrêt du traitement
          RETURN.

        ENDIF.

        " Vérifie présence de ligne Avant / Après
        IF sy-ucomm EQ lcl_main=>mc_ucomm-customizing-previous.
          " Entrée précédente
          SUBTRACT 1 FROM ls_selected_rows.

        ELSEIF sy-ucomm EQ lcl_main=>mc_ucomm-customizing-next.
          " Entrée suivante
          ADD 1 TO ls_selected_rows.

        ENDIF.

        " Vérifie cohérence de la sélection
        IF ls_selected_rows LT 0 OR ls_selected_rows GT lines( <lfs_t_table_list> ).
          " Index négatif ou dépassement taille table
          ""  --> Arrêt du traitement
          RETURN.

        ENDIF.

        " Récupération de l'entrée correspondante
        READ TABLE <lfs_t_table_list> INDEX ls_selected_rows
         ASSIGNING FIELD-SYMBOL(<lfs_s_table_list>).
        IF sy-subrc NE 0.
          " Erreur lors de la récupération de la table
          ""  --> Arrêt du traitement
          RETURN.

        ELSE.
          " Correspondance trouvée
          ""  --> Stocke sa position
          lv_tabix_tabname = sy-tabix.

        ENDIF.

        IF NOT <lfs_s_table_list> IS ASSIGNED.
          " Aucune correspondance trouvée
          ""  --> Arrêt du traitement
          RETURN.

        ENDIF.

        " Suivant l'Action utilisateur
        CASE sy-ucomm.

          WHEN lcl_main=>mc_ucomm-customizing-next
            OR lcl_main=>mc_ucomm-customizing-previous.
            " Entrée précédente // Suivante
            " Ici on va forcer la sélection de la ligne
            "" Dans certain cas de navigation, sans la méthode "REFRESH",
            "" deux lignes pouvaient être sélectionnées, ce qui n'était pas ergonomique

            ""  --> On force la déselection des lignes en rafraichissant la table
            me->ms_work_area_private-compare-customizing-display_element_table_list-o_salv->refresh( ).

            ""  --> Force la sélection sur la ligne en cours de visualisation
            lo_selections->set_selected_rows(
              value = VALUE #( ( lv_tabix_tabname ) )
            ).

            ""  --> Modification des tables de résultats
            me->_compare_display_feed_compare( <lfs_s_table_list>-tabname ).

          WHEN lcl_main=>mc_ucomm-customizing-read_more.
            " Lire plus
            ""  --> Lire plus de ligne
            me->_custo_comp_content_read_more(
              iv_tabname  = <lfs_s_table_list>-tabname
              iv_rowcount = me->ms_work_area_private-compare-system-lines_to_read->*
            ).

          WHEN OTHERS.
            " Autres

        ENDCASE. "Fin Case dépendance avec ligne sélectionée

      WHEN OTHERS.
        " Autres

    ENDCASE.

  ENDMETHOD.

  METHOD ddic_transaction_display_table.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    TRY.
        " -----------------------------------------------------------
        " Affiche la table en SE11
        " -----------------------------------------------------------

        " Affichage
        lcl_main=>_display_ddic_element(
          iv_obj_name = me->ms_work_area_private-compare-customizing-t_compare_result[ iv_row ]-tabname
          iv_obj_type = if_dd_constants=>tabl
        ).

      CATCH cx_sy_itab_line_not_found.
        " Aucune correspondance
        ""  --> Arrêt du traitement
        RETURN.

    ENDTRY.

  ENDMETHOD.

  METHOD _display_ddic_element.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Affiche l'élément DDIC
    " -----------------------------------------------------------

    " Affiche l'objet du dictionnaire
    cl_wb_ddic=>access_ddic_via_manager(
      EXPORTING
        p_obj_name              = CONV #( iv_obj_name )
        p_obj_type              = CONV #( iv_obj_type )
        p_operation             = 'S' "Affichage
      EXCEPTIONS
        action_cancelled        = 1
        object_not_found        = 2
        operation_not_supported = 3
        permission_failure      = 4
        error_occured           = 5
        OTHERS                  = 6
    ).
    IF sy-subrc NE 0.
      " Une erreur est survenue
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

  ENDMETHOD.

  METHOD customizing_on_change_line.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
    FIELD-SYMBOLS :
          <lfs_t_table_list> TYPE lcl_main=>tt_compare_customizing_com.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_tabname TYPE lcl_main=>ts_compare_customizing_com-tabname.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Pré-Traitement
    " -----------------------------------------------------------

    " Récupération nom de la table
    ASSIGN me->ms_work_area_private-compare-customizing-display_element_table_list-ot_display_data->*
        TO <lfs_t_table_list>.
    IF sy-subrc NE 0.
      " Table non pointé
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    IF iv_row IS SUPPLIED AND NOT iv_row IS INITIAL.
      " Ligne passée
      TRY.
          ""  --> Récupération Nom de la table
          lv_tabname = <lfs_t_table_list>[ iv_row ]-tabname.

        CATCH  cx_sy_itab_line_not_found.
          " Entrée non trouvée
          ""  --> Arrêt du traitement
          RETURN.

      ENDTRY.

    ELSEIF iv_tabname IS SUPPLIED AND NOT iv_tabname IS INITIAL.
      " Nom de table passée
      ""  --> Utilisation de ce nom
      lv_tabname = iv_tabname.

    ELSE.
      " Aucun paramètre
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF lv_tabname EQ
      me->ms_work_area_private-compare-customizing-display_element_table_list-current_tabname.
      " Pas de changement
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Modifie le contenu des tables
    " -----------------------------------------------------------

    " Modifie le contenu des tables
    me->_compare_display_feed_compare( lv_tabname ).

    " -----------------------------------------------------------
    " Traitement supplémentaire
    " -----------------------------------------------------------

    " Simule une action pour déclencher le PBO
    cl_gui_cfw=>set_new_ok_code( lcl_main=>mc_ucomm-common-dummy ). "#EC NOTEXT

    " Synchronisation Back & Front
    cl_gui_cfw=>flush(
      EXCEPTIONS
        cntl_error = 1
        cntl_system_error = 2
    ).
    IF sy-subrc NE 0.
      " Erreur
      ""  --> Tant pis
      CLEAR : sy-subrc.

    ENDIF.

  ENDMETHOD.

  METHOD _check_input.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle Système
    " -----------------------------------------------------------

    IF me->ms_selection_criteria-system-ov_target->* EQ me->ms_selection_criteria-system-ov_origin->*.
      " Système identique
      rv_subrc = 13.
      MESSAGE s751(tr) DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    " Contrôle système cible
    rv_subrc = me->_check_system( me->ms_selection_criteria-system-ov_target->* ).
    IF NOT rv_subrc IS INITIAL.
      " Erreur contrôle système
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " Contrôle système d'origine
    rv_subrc = me->_check_system( me->ms_selection_criteria-system-ov_origin->* ).
    IF NOT rv_subrc IS INITIAL.
      " Erreur contrôle système
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " Initialisation variable d'affichage
    ""  --> Texte système Origine
    me->ms_work_area_private-compare-system-origin->* =
      |{ text-tso } : { me->ms_selection_criteria-system-ov_origin->* }|.
    ""  --> Texte système Cible
    me->ms_work_area_private-compare-system-target->* =
      |{ text-tst } : { me->ms_selection_criteria-system-ov_target->* }|.
    ""  --> Nombre de lignes à lire
    me->ms_work_area_private-compare-system-lines_to_read->* =
      me->ms_selection_criteria-customizing-ov_rowcount->*.

  ENDMETHOD.

  METHOD _check_system.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle cohérence du système
    " -----------------------------------------------------------

    IF iv_rfcdest IS INITIAL.
      " Système non renseigné
      ""  --> Arrêt du traitement
      rv_subrc = 2.
      MESSAGE s000(tsys) DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    " Contrôle existence système
    SELECT SINGLE rfcdest
             FROM rfcdes
            WHERE rfctype EQ '3' ##NOTEXT
              AND rfcdest EQ @iv_rfcdest
      INTO @DATA(lv_rfcdest).
    IF sy-subrc NE 0.
      " Aucune correspondance
      ""  --> Arrêt du traitement
      rv_subrc = 3.
      MESSAGE s010(esh_cm_sys_coup_msg) DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

  ENDMETHOD.

  METHOD _object_get.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_subrc TYPE sy-subrc.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " Suivant le Type de Comparaison
    CASE abap_true.

      WHEN me->ms_selection_criteria-workbench-ov_activ->*.
        " -----------------------------------------------------------
        " Récupération des objets à comparer
        " -----------------------------------------------------------

        " Récupération des Objets
        rv_subrc = me->_object_workbench_get( ).

      WHEN me->ms_selection_criteria-customizing-ov_activ->*.
        " -----------------------------------------------------------
        " Récupération des Tables à comparer
        " -----------------------------------------------------------

        " Récupération des tables de Custo
        rv_subrc = me->_object_customizing_get( ).

    ENDCASE.

  ENDMETHOD.

  METHOD _object_workbench_get.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

    " -----------------------------------------------------------
    " Récupération des Packages
    " -----------------------------------------------------------
    " On "triche" ici, en récupérant les Packages des objets
    " "simples" (MF / Programme) afin de simplifier le traitement
    " -----------------------------------------------------------

    IF NOT me->ms_selection_criteria-workbench-or_obj_name->* IS INITIAL.
      ""  --> Récupération Package des Programmes
      SELECT DISTINCT devclass FROM tadir
                WHERE obj_name   IN @me->ms_selection_criteria-workbench-or_obj_name->*
      APPENDING TABLE @me->ms_work_area_private-object-workbench-t_devclass[].

    ENDIF.

    IF NOT me->ms_selection_criteria-workbench-or_funcname->* IS INITIAL.
      ""  --> Récupération Package Fonctions
      SELECT DISTINCT tadir~devclass
                 FROM tfdir
           INNER JOIN tadir ON tadir~obj_name EQ tfdir~pname_main
                WHERE tfdir~funcname IN @me->ms_selection_criteria-workbench-or_funcname->*
      APPENDING TABLE @me->ms_work_area_private-object-workbench-t_devclass[].

    ENDIF.

    IF NOT me->ms_selection_criteria-workbench-or_devclass->* IS INITIAL.
      " -->" Récupération des Packages
      SELECT devclass FROM tdevc
       WHERE devclass   IN @me->ms_selection_criteria-workbench-or_devclass->*
           APPENDING TABLE @me->ms_work_area_private-object-workbench-t_devclass.

    ENDIF.

    " Tri et suppression des doublons
    SORT me->ms_work_area_private-object-workbench-t_devclass.
    DELETE ADJACENT DUPLICATES FROM me->ms_work_area_private-object-workbench-t_devclass.

    IF me->ms_work_area_private-object-workbench-t_devclass[] IS INITIAL.
      " Aucun Package récupéré
      ""  --> Arrêt du traitement
      MESSAGE s889(tk) DISPLAY LIKE if_msg_output=>msgtype_error.
      rv_subrc = 2.
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Récupération des Objets Workbench
    " -----------------------------------------------------------

    ""  --> Récupération des objets du package
    rv_subrc = me->_object_package_get( ).

  ENDMETHOD.

  METHOD _object_customizing_get.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_fields  TYPE esh_t_co_rfcrt_fields,
      lt_options TYPE esh_t_co_rfcrt_options.
***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
          ls_compare_result TYPE lcl_main=>ts_compare_customizing_result.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_same_table  TYPE xsdboolean,
      lv_split_error TYPE xsdboolean.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation
    " -----------------------------------------------------------

    " Table des champs à récupérer
    lt_fields = VALUE #(
     ( fieldname = 'TABNAME' ) ##NOTEXT
    ).

    " Table des filtres
    DATA(lv_where_clause) = lcl_main=>range_2_where(
      ir_selopt_t  = me->ms_selection_criteria-customizing-or_tabname->*
      iv_fieldname = 'TABNAME' ##NOTEXT
    ).

    IF me->ms_selection_criteria-compare_option-ov_all_type->* EQ abap_false.
      " Filtre sur les types modifiables / custo
      lv_where_clause = |{ lv_where_clause }| &&
      | AND ( MAINFLAG EQ 'X' OR CONTFLAG EQ 'C' ) |.

    ENDIF.

    IF NOT lv_where_clause IS INITIAL.
      " Découpe le clause WHERE pour le MF RFC_READ_TABLE
      CONDENSE lv_where_clause.
      IF strlen( lv_where_clause ) LE 72.
        " La condition tient dans la table
        APPEND lv_where_clause TO lt_options.

      ELSE.
        " La condition dépasse les 72 caractères
        ""  --> Découpe sous forme de table de 72 caractères
        CALL FUNCTION 'RKD_WORD_WRAP'
          EXPORTING
            textline            = CONV char16384( lv_where_clause )
            outputlen           = 72
            delimiter           = space
          TABLES
            out_lines           = lt_options
          EXCEPTIONS
            outputlen_too_large = 1
            OTHERS              = 2.
        IF sy-subrc NE 0.
          " Erreur découpage
          ""  --> Initialise témoin erreur découpage
          lv_split_error = abap_true.

          ""  --> Réinitialisation filtre
          REFRESH : lt_options.

        ENDIF.

      ENDIF.

    ENDIF.

    " -----------------------------------------------------------
    " Sélection des Tables dans les différents systèmes
    " -----------------------------------------------------------

    " Progression début Recherche système origine
    lcl_main=>progress_display(
      iv_text       = text-rso
      iv_percentage = 50
    ).

    " Récupération table dans système d'origine
    me->_rfc_read_table(
      EXPORTING
        it_fields      = lt_fields
        it_options     = lt_options
        iv_query_table = 'DD02L' ##NOTEXT
        iv_destination = me->ms_selection_criteria-system-ov_origin->*
      IMPORTING
        et_data        = me->ms_work_area_private-object-customizing-t_tabname_origin
    ).

    " Progression début Recherche système cible
    lcl_main=>progress_display(
      iv_text       = text-rst
      iv_percentage = 100
    ).

    " Récupération table dans système cible
    me->_rfc_read_table(
      EXPORTING
        it_fields      = lt_fields
        it_options     = lt_options
        iv_query_table = 'DD02L' ##NOTEXT
        iv_destination = me->ms_selection_criteria-system-ov_target->*
      IMPORTING
        et_data        = me->ms_work_area_private-object-customizing-t_tabname_target
    ).

    IF  me->ms_work_area_private-object-customizing-t_tabname_target[] IS INITIAL
    AND me->ms_work_area_private-object-customizing-t_tabname_origin[] IS INITIAL.
      " Aucune table à comparer
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Post-Sélection
    " -----------------------------------------------------------

    IF lv_split_error EQ abap_true.
      " Erreur découpage
      ""  --> Applique le Filtre
      IF NOT me->ms_selection_criteria-customizing-or_tabname->* IS INITIAL.
        DELETE me->ms_work_area_private-object-customizing-t_tabname_target
         WHERE table_line NOT IN me->ms_selection_criteria-customizing-or_tabname->*.
        DELETE me->ms_work_area_private-object-customizing-t_tabname_origin
         WHERE table_line NOT IN me->ms_selection_criteria-customizing-or_tabname->*.

      ENDIF.

    ENDIF.

    " -----------------------------------------------------------
    " Comparaison des tables communes dans les systèmes
    " -----------------------------------------------------------

    " Tri
    SORT me->ms_work_area_private-object-customizing-t_tabname_origin.
    SORT me->ms_work_area_private-object-customizing-t_tabname_target.

    IF me->ms_work_area_private-object-customizing-t_tabname_origin[]
    EQ me->ms_work_area_private-object-customizing-t_tabname_target[].
      " Les tables sont identiques
      " --> Initialisation flag
      lv_same_table = abap_true.

    ENDIF.

    " Compare les tables présentes dans le système d'origine vs cible
    LOOP AT me->ms_work_area_private-object-customizing-t_tabname_origin
      ASSIGNING FIELD-SYMBOL(<lfs_s_tabname_origin>).

      " Initialisation structure de résultat
      ls_compare_result-tabname         = <lfs_s_tabname_origin>.
      ls_compare_result-exist_in_origin = abap_true.

      IF lv_same_table EQ abap_true.
        " Les tables sont les mêmes
        ""  --> Initialisation témoin de présence dans le sytème cible
        ls_compare_result-exist_in_target = abap_true.

      ELSE.
        " Les tables sont divergentes
        ""  --> La table existe dans le système cible ?
        READ TABLE me->ms_work_area_private-object-customizing-t_tabname_target
          WITH KEY table_line = <lfs_s_tabname_origin> TRANSPORTING NO FIELDS BINARY SEARCH.
        IF sy-subrc EQ 0.
          " Oui
          ""  --> Initialisation témoin de présence dans le sytème cible
          ls_compare_result-exist_in_target = abap_true.

        ENDIF.

      ENDIF.

      IF me->ms_selection_criteria-compare_option-ov_only_object_commun->* EQ abap_true.
        " Conserve uniquement les objets en commun
        IF ls_compare_result-exist_in_target EQ abap_false
        OR ls_compare_result-exist_in_origin EQ abap_false.
          ""  --> Passe à l'itération suivante
          CONTINUE.

        ENDIF.

      ENDIF.

      " Ajout dans table de comparaison
      READ TABLE me->ms_work_area_private-object-customizing-t_tabname_to_compare
        WITH KEY table_line = <lfs_s_tabname_origin> TRANSPORTING NO FIELDS BINARY SEARCH.
      IF sy-subrc NE 0.
        INSERT <lfs_s_tabname_origin>
          INTO me->ms_work_area_private-object-customizing-t_tabname_to_compare
         INDEX sy-tabix.

      ENDIF.

      " Ajout de l'entrée dans table de résultat
      INSERT ls_compare_result INTO TABLE me->ms_work_area_private-compare-customizing-t_compare_result.

      " Réinitialisation
      CLEAR : ls_compare_result.

    ENDLOOP.

    IF lv_same_table EQ abap_false.
      " Les tables sont divergentes
      ""  --> Compare les tables présentes dans le système cible vs origine
      LOOP AT me->ms_work_area_private-object-customizing-t_tabname_target
        ASSIGNING FIELD-SYMBOL(<lfs_s_tabname_target>).

        " Recherche de l'entrée dans table de résultat
        READ TABLE me->ms_work_area_private-compare-customizing-t_compare_result
        WITH TABLE KEY tabname = <lfs_s_tabname_target>
          TRANSPORTING NO FIELDS.
        IF sy-subrc EQ 0.
          " Table déjà traitée
          ""  --> Passe à l'itération suivante
          CONTINUE.

        ENDIF.

        " Initialisation
        ls_compare_result-tabname         = <lfs_s_tabname_target>.
        ls_compare_result-exist_in_target = abap_true.

        " Ajout de l'entrée dans table de résultat
        INSERT ls_compare_result INTO TABLE me->ms_work_area_private-compare-customizing-t_compare_result.

        " Réinitialisation
        CLEAR : ls_compare_result.

      ENDLOOP.

    ENDIF.

  ENDMETHOD.

  METHOD _rfc_table_lines_count.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_entries TYPE esh_t_co_rfcrt_data.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    CLEAR : ev_subrc.

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF iv_tabname IS INITIAL.
      " Nom table non renseigné
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Récupération nombre de lignes
    " -----------------------------------------------------------

    " Récupération du nombre de lignes
    CALL FUNCTION 'RFC_GET_TABLE_ENTRIES'
      DESTINATION iv_destination
      EXPORTING
        max_entries       = 1
        table_name        = iv_tabname
      IMPORTING
        number_of_entries = rv_lines_count
      TABLES
        entries           = lt_entries
      EXCEPTIONS
        internal_error    = 1
        table_empty       = 2
        table_not_found   = 3
        error_message     = 4
        OTHERS            = 5.
    IF sy-subrc NE 0.
      " Une erreur est survenue
      ""  --> Retourne Code d'erreur
      ev_subrc = 4.
      RETURN.

    ENDIF.

  ENDMETHOD.

  METHOD _rfc_read_table.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    REFRESH : et_fields.

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF iv_query_table IS INITIAL.
      " Nom table non renseigné
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Initialisation
    " -----------------------------------------------------------

    " Champs
    et_fields[] = it_fields[].

    " -----------------------------------------------------------
    " Sélection distance
    " -----------------------------------------------------------

    " Sélection des données distantes
    CALL FUNCTION 'RFC_READ_TABLE'
      DESTINATION iv_destination
      EXPORTING
        query_table          = iv_query_table
*       DELIMITER            = ' '
        rowskip              = iv_rowskip
        rowcount             = iv_rowcount
      TABLES
        options              = it_options
        fields               = et_fields
        data                 = et_data
      EXCEPTIONS
        table_not_available  = 1
        table_without_data   = 2
        option_not_valid     = 3
        field_not_valid      = 4
        not_authorized       = 5
        data_buffer_exceeded = 6
        error_message        = 7
        OTHERS               = 8.
    IF sy-subrc NE 0.
      " Une erreur est survenue
      rv_subrc = 4.

    ENDIF.

  ENDMETHOD.

  METHOD _object_package_get.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_both_temp        TYPE scwb_t_e071,
      lt_imp_e071_temp    TYPE scwb_t_e071,
      lt_only_origin_temp TYPE scwb_t_e071,
      lt_only_target_temp TYPE scwb_t_e071.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***


    " -----------------------------------------------------------
    " Récupération des objets des Packages
    " -----------------------------------------------------------

    " Récupération des objets des packages
    LOOP AT me->ms_work_area_private-object-workbench-t_devclass
      ASSIGNING FIELD-SYMBOL(<lfs_s_devclass>).

      " Récupération des objets contenu dans les Packages
      CALL FUNCTION 'SCTS_COMP_REPOS_COMPARE_REPOS'
        EXPORTING
          dest1                      = me->ms_selection_criteria-system-ov_origin->*
          dest2                      = me->ms_selection_criteria-system-ov_target->*
          cust_flag                  = abap_false "Objet modifié / crée
          modi_flag                  = abap_false "Objet SAP modifié
          " Recherche par Package
          paket_flag                 = abap_true
          paket_name                 = <lfs_s_devclass>
          subpaket_flag              = abap_true
          " Recherche par OT
          req_flag                   = abap_false
          req_name                   = space
          " Recherche par Objet (alimenté LT_IMP_E071)
          obj_flag                   = abap_false
          " Recherche par Autorisation
          auth_flag                  = abap_false
          name_auth                  = space
        TABLES
          et_only1                   = lt_only_origin_temp
          et_only2                   = lt_only_target_temp
          et_both12                  = lt_both_temp
          lt_imp_e071                = lt_imp_e071_temp
        EXCEPTIONS
          packet_not_in_sys1         = 1
          packet_not_in_sys2         = 2
          req_not_in_sys1            = 3
          req_not_in_sys2            = 4
          comunication_failure_dest1 = 5
          comunication_failure_dest2 = 6
          no_authority_dest2         = 7
          timeout                    = 8
          error_message              = 9
          OTHERS                     = 10.
      IF sy-subrc EQ 0.
        " Récupération effectuée
        ""  --> Ajout des données
        APPEND LINES OF :
          lt_both_temp     TO me->ms_work_area_private-object-workbench-t_object_to_compare,
          lt_only_origin_temp TO me->ms_work_area_private-object-workbench-t_only_origin,
          lt_only_target_temp TO me->ms_work_area_private-object-workbench-t_only_target.

      ENDIF.

      " Réinitialisation
      REFRESH : lt_only_origin_temp, lt_both_temp,
                lt_only_target_temp, lt_imp_e071_temp.

    ENDLOOP.

    " -----------------------------------------------------------
    " Post-Récupération
    " -----------------------------------------------------------

    " Suppression des objets non supportées
    DELETE me->ms_work_area_private-object-workbench-t_object_to_compare
     WHERE object = 'DEVC'. " no support for DEVC in 7.x/6.

  ENDMETHOD.

  METHOD _compare_object.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF ( me->ms_selection_criteria-workbench-ov_activ->* EQ abap_true
      AND me->ms_work_area_private-object-workbench-t_object_to_compare[] IS INITIAL )
    OR ( me->ms_selection_criteria-customizing-ov_activ->* EQ abap_true
      AND me->ms_work_area_private-object-customizing-t_tabname_to_compare[] IS INITIAL ).
      " Aucune données à comparer
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Comparaison des objets
    " -----------------------------------------------------------

    " Suivant le Type de comparaison
    CASE abap_true.

      WHEN me->ms_selection_criteria-workbench-ov_activ->*.
        " Workbench
        rv_subrc = me->_compare_object_workbench( ).

      WHEN me->ms_selection_criteria-customizing-ov_activ->*.
        " Customizing
        rv_subrc = me->_compare_object_customizing( ).

      WHEN OTHERS.
        " Autre
        ""  --> Non prévu // Arrêt du traitement
        RETURN.

    ENDCASE.

  ENDMETHOD.

  METHOD _compare_object_workbench.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF me->ms_work_area_private-object-workbench-t_object_to_compare[] IS INITIAL.
      " Aucune données à comparer
      rv_subrc = 1.
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Comparaison des Objets de Workbench
    " -----------------------------------------------------------

    " Comparaison des objets
    CALL FUNCTION 'SVRS_MASSCOMPARE_ACT_OBJECTS'
      EXPORTING
        it_e071                = me->ms_work_area_private-object-workbench-t_object_to_compare
        iv_rfcdest_a           = me->ms_selection_criteria-system-ov_origin->*
        iv_rfcdest_b           = me->ms_selection_criteria-system-ov_target->*
        iv_filter_lang         = abap_true
*       iv_delete_lang         = abap_false
*       iv_abap_ignore_case    = abap_true
*       iv_abap_condense       = abap_true
*       iv_abap_ignore_comments = abap_true
*       iv_abap_equivalence    = abap_true
*       iv_with_gui_progress   = abap_true
        iv_ignore_report_text  = abap_true
      IMPORTING
        et_compare_items       = me->ms_work_area_private-compare-workbench-t_compare_items
        es_rfcsi_a             = me->ms_work_area_private-compare-workbench-s_rfcsi_origin
        es_rfcsi_b             = me->ms_work_area_private-compare-workbench-s_rfcsi_target
        et_nonversionable_e071 = me->ms_work_area_private-compare-workbench-t_nonvers
      EXCEPTIONS
        rfc_error              = 1
        not_supported          = 2
        error_message          = 3
        OTHERS                 = 4.
    IF sy-subrc NE 0.
      " Une erreur est survenue
      ""  --> Retourne erreur
      rv_subrc = 6.
      MESSAGE ID sy-msgid TYPE if_msg_output=>msgtype_success
          NUMBER sy-msgno WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
                  DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    IF me->ms_selection_criteria-compare_option-ov_only_difference->* EQ abap_true.
      " Filtre les versions équivalentes
      DELETE me->ms_work_area_private-compare-workbench-t_compare_items
       WHERE equal EQ abap_true.

    ENDIF.

  ENDMETHOD.

  METHOD _compare_object_customizing.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

    " -----------------------------------------------------------
    " Comparaison des tables
    " -----------------------------------------------------------

    " Comparaison des tables
    rv_subrc = me->_customizing_compare_table(
      iv_rowcount           = me->ms_selection_criteria-customizing-ov_rowcount->*
      it_tabname_to_compare = me->ms_work_area_private-object-customizing-t_tabname_to_compare[]
    ).

  ENDMETHOD.

  METHOD _customizing_compare_table.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_data_target   TYPE esh_t_co_rfcrt_data,
      lt_data_origin   TYPE esh_t_co_rfcrt_data,
      lt_fields_origin TYPE esh_t_co_rfcrt_fields,
      lt_fields_target TYPE esh_t_co_rfcrt_fields.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_text       TYPE string,
      lv_lines      TYPE string,
      lv_integer    TYPE int4,
      lv_percentage TYPE string.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF it_tabname_to_compare[] IS INITIAL.
      " Aucune données à comparer
      rv_subrc = 1.
      RETURN.

    ENDIF.

    " Initialisation nombre d'enregistrement
    lv_lines = lv_integer = |{ lines( it_tabname_to_compare ) ZERO = NO }|.

    " -----------------------------------------------------------
    " Récupération des tables dans les différents système
    " -----------------------------------------------------------

    LOOP AT it_tabname_to_compare
      ASSIGNING FIELD-SYMBOL(<lfs_s_tabname_to_compare>).

      CLEAR : lv_percentage, lv_text.

      " Initialisation texte et progression
      lv_text = text-pct.
      ""  --> Itération
      lv_percentage = lv_integer = |{ sy-tabix ZERO = NO }|.
      REPLACE '&1' WITH lv_percentage INTO lv_text.         "#EC NOTEXT
      ""  --> Total
      REPLACE '&2' WITH lv_lines INTO lv_text.              "#EC NOTEXT
      ""  --> Nom table
      REPLACE '&3' WITH <lfs_s_tabname_to_compare> INTO lv_text. "#EC NOTEXT

      ""  --> Progression
      lv_percentage = |{ ( sy-tabix * 100 / lv_lines ) ZERO = NO }|.

      " Progression comparaison table
      lcl_main=>progress_display(
        iv_text       = lv_text
        iv_percentage = CONV #( lv_percentage )
      ).

      " Récupération de l'entrée correspondance
      READ TABLE me->ms_work_area_private-compare-customizing-t_compare_result
      WITH TABLE KEY tabname = <lfs_s_tabname_to_compare>
       ASSIGNING FIELD-SYMBOL(<lfs_s_compare_result>).

      IF <lfs_s_compare_result>-exist_in_origin EQ abap_true.
        " Récupération nombre de lignes - Origine
        <lfs_s_compare_result>-lines_count_origin = me->_rfc_table_lines_count(
          iv_tabname     = <lfs_s_tabname_to_compare>
          iv_destination = me->ms_selection_criteria-system-ov_origin->*
        ).

        " Récupération données - Origine
        me->_rfc_read_table(
          EXPORTING
            iv_rowcount    = iv_rowcount
            iv_query_table = <lfs_s_tabname_to_compare>
            iv_destination = me->ms_selection_criteria-system-ov_origin->*
          IMPORTING
            et_data        = lt_data_origin
            et_fields      = lt_fields_origin
        ).

        " Réinitialisation des champs pouvant provoquer des errurs de comparaison
        LOOP AT lt_fields_origin ASSIGNING FIELD-SYMBOL(<lfs_s_fields_origin>).
          CLEAR : <lfs_s_fields_origin>-fieldtext.
        ENDLOOP.

        " Tri
        SORT : lt_fields_origin BY offset, lt_data_origin.

      ENDIF.

      IF <lfs_s_compare_result>-exist_in_target EQ abap_true.
        " Récupération nombre de lignes - Cible
        <lfs_s_compare_result>-lines_count_target = me->_rfc_table_lines_count(
          iv_tabname     = <lfs_s_tabname_to_compare>
          iv_destination = me->ms_selection_criteria-system-ov_target->*
        ).

        " Récupération données - Cible
        me->_rfc_read_table(
          EXPORTING
            iv_rowcount    = iv_rowcount
            iv_query_table = <lfs_s_tabname_to_compare>
            iv_destination = me->ms_selection_criteria-system-ov_target->*
          IMPORTING
            et_data        = lt_data_target
            et_fields      = lt_fields_target
        ).

        " Réinitialisation des champs pouvant provoquer des errurs de comparaison
        LOOP AT lt_fields_target ASSIGNING FIELD-SYMBOL(<lfs_s_fields_target>).
          CLEAR : <lfs_s_fields_target>-fieldtext.
        ENDLOOP.

        " Tri
        SORT : lt_fields_target BY offset, lt_data_target.

      ENDIF.

      " Comparaison
      me->_custo_compare_content_table(
          iv_tablename     = <lfs_s_tabname_to_compare>
          it_data_origin   = lt_data_origin
          it_data_target   = lt_data_target
          it_fields_origin = lt_fields_origin
          it_fields_target = lt_fields_target
      ).

      " Réinitialisation
      REFRESH : lt_fields_origin, lt_data_origin,
                lt_fields_target, lt_data_target.

    ENDLOOP.

  ENDMETHOD.

  METHOD _compare_display.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Affichage de la Comparaison
    " -----------------------------------------------------------

    " Suivant le Type
    CASE abap_true.

      WHEN me->ms_selection_criteria-workbench-ov_activ->*.
        " Workbench
        ""  --> Affichage résultat comparaison
        me->_compare_display_workbench( ).

      WHEN me->ms_selection_criteria-customizing-ov_activ->*.
        " Customizing
        ""  --> Affichage résultat comparaison
        me->_compare_display_customizing( ).

      WHEN OTHERS.

    ENDCASE.

  ENDMETHOD.

  METHOD _compare_display_workbench.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
          ls_compare_result TYPE lcl_main=>ts_compare_workbench_result.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_column     TYPE REF TO cl_salv_column,
      lo_ccontainer TYPE REF TO cl_gui_custom_container.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_id_result       TYPE sysuuid_c32,
      lv_timestamp       TYPE timestamp,
      lv_exist_in_origin TYPE xsdboolean,
      lv_exist_in_target TYPE xsdboolean.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Préparation données à afficher
    " -----------------------------------------------------------

    " Timestamp
    GET TIME STAMP FIELD lv_timestamp.

    TRY.
        lv_id_result = cl_system_uuid=>create_uuid_c32_static( ).

      CATCH cx_uuid_error.
        " Erreur
        "" --> Génération Nombre aléatoire
        lv_id_result = cl_abap_random=>seed( ).

    ENDTRY.

    " Tri pour Perf
    SORT me->ms_work_area_private-object-workbench-t_only_origin BY object obj_name.
    SORT me->ms_work_area_private-object-workbench-t_only_target BY object obj_name.
    SORT me->ms_work_area_private-compare-workbench-t_compare_items BY object obj_name.

    " Aliemntation table de résultat
    LOOP AT me->ms_work_area_private-object-workbench-t_object_to_compare
      ASSIGNING FIELD-SYMBOL(<lfs_s_object_to_compare>).

      " Objet existe uniquement dans le système d'Origine ?
      READ TABLE me->ms_work_area_private-object-workbench-t_only_origin
        WITH KEY object   = <lfs_s_object_to_compare>-object
                 obj_name = <lfs_s_object_to_compare>-obj_name
               TRANSPORTING NO FIELDS BINARY SEARCH.
      lv_exist_in_origin = xsdbool( sy-subrc NE 0 ).

      " Objet existe uniquement dans le système Cible ?
      READ TABLE me->ms_work_area_private-object-workbench-t_only_origin
        WITH KEY object   = <lfs_s_object_to_compare>-object
                 obj_name = <lfs_s_object_to_compare>-obj_name
               TRANSPORTING NO FIELDS BINARY SEARCH.
      lv_exist_in_target = xsdbool( sy-subrc NE 0 ).

      " Recherche première itération dans détail de comparaison
      READ TABLE me->ms_work_area_private-compare-workbench-t_compare_items
        WITH KEY object   = <lfs_s_object_to_compare>-object
                 obj_name = <lfs_s_object_to_compare>-obj_name
               TRANSPORTING NO FIELDS BINARY SEARCH.
      IF sy-subrc EQ 0.
        " Au moins une correspondance
        ""  --> Parcours toutes les entrées correspondants
        LOOP AT me->ms_work_area_private-compare-workbench-t_compare_items
          ASSIGNING FIELD-SYMBOL(<lfs_s_compare_item>) FROM sy-tabix.

          IF <lfs_s_compare_item>-object   NE <lfs_s_object_to_compare>-object
          OR <lfs_s_compare_item>-obj_name NE <lfs_s_object_to_compare>-obj_name.
            " On ne traite plus le même objet
            ""  --> Arrêt de la boucle
            EXIT.

          ENDIF.

          " Initialisation données
          ls_compare_result = CORRESPONDING #(
            <lfs_s_compare_item> MAPPING
              package_origin = devclass_a
              package_target = devclass_b
          ).

          " Initialisation champs Log
          ls_compare_result-uname     = sy-uname.
          ls_compare_result-timestamp = lv_timestamp.
          ls_compare_result-id_result = lv_id_result.

          " Initialisation existe dans système d'origine
          ls_compare_result-exist_in_origin      = lv_exist_in_origin.
          ls_compare_result-exist_in_origin_icon = SWITCH #( ls_compare_result-exist_in_origin
            WHEN abap_true THEN text-s00
            ELSE text-e00
          ).

          " Initialisation existe dans système cible
          ls_compare_result-exist_in_target      = lv_exist_in_target.
          ls_compare_result-exist_in_target_icon = SWITCH #( ls_compare_result-exist_in_target
            WHEN abap_true THEN text-s00
            ELSE text-e00
          ).

          " Initialisation Icône - Equivalence
          ls_compare_result-equal_icon = SWITCH #( ls_compare_result-equal
            WHEN abap_true THEN text-s00
            ELSE text-e00
          ).

          " Initialisation Icône - Non versionnable
          ls_compare_result-nonversionable_icon = SWITCH #( ls_compare_result-nonversionable
            WHEN abap_true THEN text-e00
            ELSE text-s00
          ).

          " Initialisation Icône - Non lisable
          ls_compare_result-not_readable_icon = SWITCH #( ls_compare_result-not_readable_icon
            WHEN abap_true THEN text-e00
            ELSE text-s00
          ).

          " Initialisation Icône - Non comparable
          ls_compare_result-not_comparable_icon = SWITCH #( ls_compare_result-not_comparable_icon
            WHEN abap_true THEN text-e00
            ELSE text-s00
          ).

          " Initialisation Icône - Non comparable
          ls_compare_result-not_comparable_icon = SWITCH #( ls_compare_result-not_comparable_icon
            WHEN abap_true THEN text-e00
            ELSE text-s00
          ).

          " Icône de la ligne
          ls_compare_result-icon = SWITCH #(
            xsdbool(
              ls_compare_result-equal           EQ abap_false OR
              ls_compare_result-exist_in_target EQ abap_false OR
              ls_compare_result-exist_in_origin EQ abap_false OR
              ls_compare_result-not_readable    EQ abap_true  OR
              ls_compare_result-nonversionable  EQ abap_true  OR
              ls_compare_result-not_comparable  EQ abap_true
            )
              WHEN abap_true THEN text-e00
              ELSE text-s00
          ).

          " Ajout de l'entrée
          APPEND ls_compare_result TO me->ms_work_area_private-compare-workbench-display_element-t_display_data.

        ENDLOOP.

      ELSE.
        IF me->ms_selection_criteria-compare_option-ov_only_difference->* EQ abap_false.
          " Aucune correspondance
          ""  --> Initialisation champs Log
          ls_compare_result-uname     = sy-uname.
          ls_compare_result-timestamp = lv_timestamp.
          ls_compare_result-id_result = lv_id_result.

          ""  --> Initialisation existe dans système d'origine
          ls_compare_result-exist_in_origin      = lv_exist_in_origin.
          ls_compare_result-exist_in_origin_icon = SWITCH #( ls_compare_result-exist_in_origin
            WHEN abap_true THEN text-s00
            ELSE text-e00
          ).

          ""  --> Initialisation existe dans système cible
          ls_compare_result-exist_in_target      = lv_exist_in_target.
          ls_compare_result-exist_in_target_icon = SWITCH #( ls_compare_result-exist_in_target
            WHEN abap_true THEN text-s00
            ELSE text-e00
          ).
          ""  --> Ajout de l'entrée
          APPEND ls_compare_result TO me->ms_work_area_private-compare-workbench-display_element-t_display_data.

        ENDIF.

      ENDIF.

    ENDLOOP.

    " -----------------------------------------------------------
    " Post-Traitement
    " -----------------------------------------------------------

    " Recherche présence d'anomalie
    IF line_exists( me->ms_work_area_private-compare-workbench-display_element-t_display_data[ icon = text-e00 ] ).
      " Anomalie présente
      ""  --> Tri par Statut
      SORT me->ms_work_area_private-compare-workbench-display_element-t_display_data
        BY icon DESCENDING object obj_name.

    ENDIF.

    TRY.
        " -----------------------------------------------------------
        " Préparation ALV
        " -----------------------------------------------------------

        " Création instance Container
        CREATE OBJECT lo_ccontainer
          EXPORTING
            container_name              = CONV char30( 'CC_WORKBENCH_COMPARE_RESULT' ) "#EC NOTEXT
          EXCEPTIONS
            cntl_error                  = 1
            cntl_system_error           = 2
            create_error                = 3
            lifetime_error              = 4
            lifetime_dynpro_dynpro_link = 5
            OTHERS                      = 6.
        IF sy-subrc EQ 0.
          " Move-Cast
          ""  --> Container
          me->ms_work_area_private-compare-workbench-display_element-o_container ?= lo_ccontainer.

        ENDIF.

        " -----------------------------------------------------------
        " Préparation de l'instance ALV
        " -----------------------------------------------------------

        " Génération instance ALV
        cl_salv_table=>factory(
           EXPORTING
             r_container    = me->ms_work_area_private-compare-workbench-display_element-o_container
             container_name = 'CC_WORKBENCH_COMPARE_RESULT' "#EC NOTEXT
           IMPORTING
             r_salv_table   = me->ms_work_area_private-compare-workbench-display_element-o_salv
           CHANGING
             t_table        = me->ms_work_area_private-compare-workbench-display_element-t_display_data
         ).

        " Préparation fonction disponible
        me->ms_work_area_private-compare-workbench-display_element-o_salv->get_functions( )->set_default( abap_true ).

        TRY.
            " Modification FC
            DATA(lo_columns) = me->ms_work_area_private-compare-workbench-display_element-o_salv->get_columns( ).

            TRY.
                " ID Résultat
                lo_column = lo_columns->get_column( 'ID_RESULT' ). "#EC NOTEXT
                lo_column->set_visible( abap_false ).
                lo_column->set_technical( abap_true ).

              CATCH cx_salv_not_found.

            ENDTRY.

            TRY.
                " Nom
                lo_column = lo_columns->get_column( 'UNAME' ). "#EC NOTEXT
                lo_column->set_visible( abap_false ).
                lo_column->set_technical( abap_true ).

              CATCH cx_salv_not_found.

            ENDTRY.

            TRY.
                " Timestamp
                lo_column = lo_columns->get_column( 'TIMESTAMP' ). "#EC NOTEXT
                lo_column->set_visible( abap_false ).
                lo_column->set_technical( abap_true ).

              CATCH cx_salv_not_found.

            ENDTRY.

            TRY.
                " Nom Objet
                lo_column = lo_columns->get_column( 'OBJ_NAME' ). "#EC NOTEXT
                lo_column->set_optimized( abap_true ).

              CATCH cx_salv_not_found.

            ENDTRY.

            TRY.
                " Nom Sous-Objet
                lo_column = lo_columns->get_column( 'FRAGNAME' ). "#EC NOTEXT
                lo_column->set_optimized( abap_true ).

              CATCH cx_salv_not_found.

            ENDTRY.

            TRY.
                " Package Origine
                lo_column = lo_columns->get_column( 'DEVCLASS_A' ). "#EC NOTEXT
                lo_column->set_output_length( 10 ).

              CATCH cx_salv_not_found.

            ENDTRY.

            TRY.
                " Package Cible
                lo_column = lo_columns->get_column( 'DEVCLASS_B' ). "#EC NOTEXT
                lo_column->set_output_length( 10 ).

              CATCH cx_salv_not_found.

            ENDTRY.

            TRY.
                " Existe dans système cible
                lo_column = lo_columns->get_column( 'EXIST_IN_TARGET' ). "#EC NOTEXT
                lo_column->set_visible( abap_false ).

              CATCH cx_salv_not_found.

            ENDTRY.

            TRY.
                " Existe dans système cible - Icône
                lo_column = lo_columns->get_column( 'EXIST_IN_TARGET_ICON' ). "#EC NOTEXT
                lo_column->set_output_length( 22 ).
                lo_column->set_long_text( CONV #( text-tet ) ).
                lo_column->set_short_text( CONV #( text-tet ) ).
                lo_column->set_medium_text( CONV #( text-tet ) ).

              CATCH cx_salv_not_found.

            ENDTRY.

            TRY.
                " Existe dans système d'origine
                lo_column = lo_columns->get_column( 'EXIST_IN_ORIGIN' ). "#EC NOTEXT
                lo_column->set_visible( abap_false ).

              CATCH cx_salv_not_found.

            ENDTRY.

            TRY.
                " Existe dans système d'origine - Icône
                lo_column = lo_columns->get_column( 'EXIST_IN_ORIGIN_ICON' ). "#EC NOTEXT
                lo_column->set_output_length( 22 ).
                lo_column->set_long_text( CONV #( text-teo ) ).
                lo_column->set_short_text( CONV #( text-teo ) ).
                lo_column->set_medium_text( CONV #( text-teo ) ).

              CATCH cx_salv_not_found.

            ENDTRY.

            TRY.
                " Non lisable
                lo_column = lo_columns->get_column( 'NOT_READABLE' ). "#EC NOTEXT
                lo_column->set_visible( abap_false ).

              CATCH cx_salv_not_found.

            ENDTRY.

            TRY.
                " Non lisable - Icône
                lo_column = lo_columns->get_column( 'NOT_READABLE_ICON' ). "#EC NOTEXT
                lo_column->set_output_length( 8 ).
                lo_column->set_long_text( CONV #( text-tnr ) ).
                lo_column->set_short_text( CONV #( text-tnr ) ).
                lo_column->set_medium_text( CONV #( text-tnr ) ).

              CATCH cx_salv_not_found.

            ENDTRY.

            TRY.
                " Non Versionnable
                lo_column = lo_columns->get_column( 'NONVERSIONABLE' ). "#EC NOTEXT
                lo_column->set_visible( abap_false ).

              CATCH cx_salv_not_found.

            ENDTRY.

            TRY.
                " Non Versionnable - Icône
                lo_column = lo_columns->get_column( 'NONVERSIONABLE_ICON' ). "#EC NOTEXT
                lo_column->set_output_length( 13 ).
                lo_column->set_long_text( CONV #( text-tnv ) ).
                lo_column->set_short_text( CONV #( text-tnv ) ).
                lo_column->set_medium_text( CONV #( text-tnv ) ).

              CATCH cx_salv_not_found.

            ENDTRY.

            TRY.
                " Non Comparable
                lo_column = lo_columns->get_column( 'NOT_COMPARABLE' ). "#EC NOTEXT
                lo_column->set_visible( abap_false ).

              CATCH cx_salv_not_found.

            ENDTRY.

            TRY.
                " Non Comparable - Icône
                lo_column = lo_columns->get_column( 'NOT_COMPARABLE_ICON' ). "#EC NOTEXT
                lo_column->set_output_length( 14 ).
                lo_column->set_long_text( CONV #( text-tnc ) ).
                lo_column->set_short_text( CONV #( text-tnc ) ).
                lo_column->set_medium_text( CONV #( text-tnc ) ).

              CATCH cx_salv_not_found.

            ENDTRY.

            TRY.
                " Egale
                lo_column = lo_columns->get_column( 'EQUAL' ). "#EC NOTEXT
                lo_column->set_visible( abap_false ).

              CATCH cx_salv_not_found.

            ENDTRY.

            TRY.
                " Egale - Icône
                lo_column = lo_columns->get_column( 'EQUAL_ICON' ). "#EC NOTEXT
                lo_column->set_visible( abap_false ).
                lo_column->set_output_length( 10 ).
                lo_column->set_long_text( CONV #( text-teq ) ).
                lo_column->set_short_text( CONV #( text-teq ) ).
                lo_column->set_medium_text( CONV #( text-teq ) ).

              CATCH cx_salv_not_found.

            ENDTRY.

          CATCH cx_root.                                 "#EC NOHANDLER

        ENDTRY.

        " -----------------------------------------------------------
        " Affichage résultat comparaison
        " -----------------------------------------------------------

        CALL SCREEN 2000.

      CATCH cx_root.
        " Erreur création Container
        ""  --> On verra
        RETURN.

    ENDTRY.

  ENDMETHOD.

  METHOD _compare_display_customizing.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_events            TYPE REF TO cl_salv_events_table,
      lo_column            TYPE REF TO cl_salv_column,
      lo_columns           TYPE REF TO cl_salv_columns,
      lo_column_table      TYPE REF TO cl_salv_column_table,
      lo_ccontainer        TYPE REF TO cl_gui_custom_container,
      lo_de_table_list     TYPE REF TO lcl_main=>ts_compare_customizing_de_tab,
      lo_de_content_target TYPE REF TO lcl_main=>ts_compare_customizing_de_tab,
      lo_de_content_origin TYPE REF TO lcl_main=>ts_compare_customizing_de_tab.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
    FIELD-SYMBOLS :
      <lfs_t_table_list> TYPE lcl_main=>tt_compare_customizing_com.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Pré-Traitement
    " -----------------------------------------------------------

    " Initialisation raccourci syntaxique
    lo_de_table_list     = REF #( me->ms_work_area_private-compare-customizing-display_element_table_list ).
    lo_de_content_origin = REF #( me->ms_work_area_private-compare-customizing-display_element_content_origin ).
    lo_de_content_target = REF #( me->ms_work_area_private-compare-customizing-display_element_content_target ).

    " Liste de résultat - Initialisation pointeur sur données
    CREATE DATA lo_de_table_list->ot_display_data TYPE lcl_main=>tt_compare_customizing_com.
    ASSIGN lo_de_table_list->ot_display_data->* TO <lfs_t_table_list>.

    " -----------------------------------------------------------
    " Préparation des données à afficher
    " -----------------------------------------------------------

    " Alimentation table d'affichage
    LOOP AT me->ms_work_area_private-compare-customizing-t_compare_result
      ASSIGNING FIELD-SYMBOL(<lfs_s_compare_result>).

      " Erreur comparaison - Initialisation Icône
      <lfs_s_compare_result>-compare_error_icon = SWITCH #(
        <lfs_s_compare_result>-compare_error
          WHEN abap_true THEN text-e00
          ELSE text-s00
      ).

      " Existe système cible - Initialisation Icône
      <lfs_s_compare_result>-exist_in_target_icon = SWITCH #(
        <lfs_s_compare_result>-exist_in_target
          WHEN abap_false THEN text-e00
          ELSE text-s00
      ).

      " Existe système origine - Initialisation Icône
      <lfs_s_compare_result>-exist_in_origin_icon = SWITCH #(
        <lfs_s_compare_result>-exist_in_origin
          WHEN abap_false THEN text-e00
          ELSE text-s00
      ).

      " Structure identique - Initialisation Icône
      <lfs_s_compare_result>-identical_structure_icon = SWITCH #(
        <lfs_s_compare_result>-identical_structure
          WHEN abap_false THEN text-e00
          ELSE text-s00
      ).

      " Aucun champ en commun - Initialisation Icône
      <lfs_s_compare_result>-no_common_fields_icon = SWITCH #(
        <lfs_s_compare_result>-no_common_fields
          WHEN abap_true  THEN text-e00
          WHEN abap_false THEN space
          ELSE space
      ).

      " Aucune différence de contenu - Initialisation Icône
      <lfs_s_compare_result>-no_content_difference_icon = SWITCH #(
        <lfs_s_compare_result>-no_content_difference
          WHEN abap_true      THEN text-s00
          WHEN abap_false     THEN text-e00
          WHEN abap_undefined THEN text-i00
      ).

      " Icône affichage
      <lfs_s_compare_result>-display_icon = text-icd.

      " Ajout de l'entrée
      APPEND CORRESPONDING #( <lfs_s_compare_result> ) TO <lfs_t_table_list>.

    ENDLOOP.

    IF NOT <lfs_t_table_list> IS ASSIGNED.
      " Pointeur non initialisé
      ""  --> Arrêt du traitement
      rv_subrc = 8.
      RETURN.

    ENDIF.

    IF lines( <lfs_t_table_list> ) GT 1.
      ""  --> Propriété affichage bouton précédent : Actif
      me->ms_work_area_private-compare-customizing-screen_properties-btn_next_active = abap_true.

    ENDIF.

    TRY.
        " -----------------------------------------------------------
        " Création ALV - Liste de table & Résultat comparaison
        " -----------------------------------------------------------

        " Initialisation de l'ALV
        ""  --> Création instance Container - Liste table
        CREATE OBJECT lo_ccontainer
          EXPORTING
            container_name              = 'CC_TABLE_LIST' ##NOTEXT
          EXCEPTIONS
            cntl_error                  = 1
            cntl_system_error           = 2
            create_error                = 3
            lifetime_error              = 4
            lifetime_dynpro_dynpro_link = 5
            OTHERS                      = 6.
        IF sy-subrc EQ 0.
          " Move-Cast
          lo_de_table_list->o_container ?= lo_ccontainer.

          ""  --> Création de l'ALV
          cl_salv_table=>factory(
            EXPORTING
              r_container    = lo_de_table_list->o_container
              container_name = 'CC_TABLE_LIST' ##NOTEXT
            IMPORTING
              r_salv_table   = lo_de_table_list->o_salv
            CHANGING
              t_table        = <lfs_t_table_list>
          ).

          ""  --> Modification sélection
          lo_de_table_list->o_salv->get_selections( )->set_selection_mode(
            if_salv_c_selection_mode=>single
          ).

          ""  --> Souscription aux Evènements
          lo_events = lo_de_table_list->o_salv->get_event( ).
          CREATE OBJECT lo_de_table_list->o_event_handler
            EXPORTING
              io_main       = me
              iv_salv_id    = lcl_main=>mc_salv_id-customizing-table_list
              io_salv_table = lo_de_table_list->o_salv.
          SET HANDLER lo_de_table_list->o_event_handler->on_link_click   FOR lo_events.
          SET HANDLER lo_de_table_list->o_event_handler->on_double_click FOR lo_events.

          ""  --> Modification fonction de base
          lo_de_table_list->o_salv->get_functions( )->set_default( abap_true ).

          ""  --> Modification FC
          lo_columns = lo_de_table_list->o_salv->get_columns( ).

          TRY.
              ""  --> Icône
              lo_column_table ?= lo_columns->get_column( 'DISPLAY_ICON' ). "#EC NOTEXT
              lo_column_table->set_icon( if_salv_c_bool_sap=>true ).
              lo_column_table->set_cell_type( if_salv_c_cell_type=>hotspot ).

            CATCH cx_root.                              "#EC NO_HANDLER
              " Erreur
              ""  --> Tant pis ...

          ENDTRY.

          TRY.
              ""  --> Nom de table
              lo_column_table ?= lo_columns->get_column( 'TABNAME' ). "#EC NOTEXT
              lo_column_table->set_cell_type( if_salv_c_cell_type=>link ).

            CATCH cx_root.                              "#EC NO_HANDLER
              " Erreur
              ""  --> Tant pis ...

          ENDTRY.

          TRY.
              " Origine - Nombre de lignes
              lo_column = lo_columns->get_column( 'LINES_COUNT_ORIGIN' ). "#EC NOTEXT
              lo_column->set_output_length( 15 ).
              lo_column->set_long_text( CONV #( text-tlo ) ).
              lo_column->set_short_text( CONV #( text-tlo ) ).
              lo_column->set_medium_text( CONV #( text-tlo ) ).

            CATCH cx_salv_not_found.

          ENDTRY.

          TRY.
              " Cible - Nombre de lignes
              lo_column = lo_columns->get_column( 'LINES_COUNT_TARGET' ). "#EC NOTEXT
              lo_column->set_output_length( 13 ).
              lo_column->set_long_text( CONV #( text-tlt ) ).
              lo_column->set_short_text( CONV #( text-tlt ) ).
              lo_column->set_medium_text( CONV #( text-tlt ) ).

            CATCH cx_salv_not_found.

          ENDTRY.

          TRY.
              ""  --> Modification colonne - Erreur comparaison
              lo_column = lo_columns->get_column( 'COMPARE_ERROR' ). "#EC NOTEXT
              lo_column->set_visible( abap_false ).

            CATCH cx_root.                              "#EC NO_HANDLER
              " Erreur
              ""  --> Tant pis ...

          ENDTRY.

          TRY.
              ""  --> Modification colonne - Erreur comparaison
              lo_column = lo_columns->get_column( 'COMPARE_ERROR_ICON' ). "#EC NOTEXT
              lo_column->set_long_text( CONV #( text-tce ) ).
              lo_column->set_short_text( CONV #( text-tce ) ).
              lo_column->set_medium_text( CONV #( text-tce ) ).
              lo_column->set_output_length( 15 ).

            CATCH cx_root.                              "#EC NO_HANDLER
              " Erreur
              ""  --> Tant pis ...

          ENDTRY.

          TRY.
              ""  --> Modification colonne - Existe dans le système d'Origine ?
              lo_column = lo_columns->get_column( 'EXIST_IN_ORIGIN' ). "#EC NOTEXT
              lo_column->set_visible( abap_false ).

            CATCH cx_root.                              "#EC NO_HANDLER
              " Erreur
              ""  --> Tant pis ...

          ENDTRY.

          TRY.
              ""  --> Modification colonne - Existe dans le système d'Origine ?
              lo_column = lo_columns->get_column( 'EXIST_IN_ORIGIN_ICON' ). "#EC NOTEXT
              lo_column->set_long_text( CONV #( text-teo ) ).
              lo_column->set_short_text( CONV #( text-teo ) ).
              lo_column->set_medium_text( CONV #( text-teo ) ).
              lo_column->set_output_length( 22 ).

            CATCH cx_root.                              "#EC NO_HANDLER
              " Erreur
              ""  --> Tant pis ...

          ENDTRY.

          TRY.
              ""  --> Modification colonne - Existe dans le système Cible ?
              lo_column = lo_columns->get_column( 'EXIST_IN_TARGET' ). "#EC NOTEXT
              lo_column->set_visible( abap_false ).

            CATCH cx_root.                              "#EC NO_HANDLER
              " Erreur
              ""  --> Tant pis ...

          ENDTRY.

          TRY.
              ""  --> Modification colonne - Existe dans le système Cible ?
              lo_column = lo_columns->get_column( 'EXIST_IN_TARGET_ICON' ). "#EC NOTEXT
              lo_column->set_long_text( CONV #( text-tet ) ).
              lo_column->set_short_text( CONV #( text-tet ) ).
              lo_column->set_medium_text( CONV #( text-tet ) ).
              lo_column->set_output_length( 20 ).

            CATCH cx_root.                              "#EC NO_HANDLER
              " Erreur
              ""  --> Tant pis ...

          ENDTRY.

          TRY.
              ""  --> Modification colonne - Aucun champ en commun
              lo_column = lo_columns->get_column( 'NO_COMMON_FIELDS' ). "#EC NOTEXT
              lo_column->set_visible( abap_false ).

            CATCH cx_root.                              "#EC NO_HANDLER
              " Erreur
              ""  --> Tant pis ...

          ENDTRY.

          TRY.
              ""  --> Modification colonne - Aucun champ en commun
              lo_column = lo_columns->get_column( 'NO_COMMON_FIELDS_ICON' ). "#EC NOTEXT
              lo_column->set_long_text( CONV #( text-tnf ) ).
              lo_column->set_short_text( CONV #( text-tnf ) ).
              lo_column->set_medium_text( CONV #( text-tnf ) ).
              lo_column->set_output_length( 22 ).

            CATCH cx_root.                              "#EC NO_HANDLER
              " Erreur
              ""  --> Tant pis ...

          ENDTRY.

          TRY.
              ""  --> Modification colonne - Structure identique
              lo_column = lo_columns->get_column( 'IDENTICAL_STRUCTURE' ). "#EC NOTEXT
              lo_column->set_visible( abap_false ).

            CATCH cx_root.                              "#EC NO_HANDLER
              " Erreur
              ""  --> Tant pis ...

          ENDTRY.

          TRY.
              ""  --> Modification colonne - Structure identique
              lo_column = lo_columns->get_column( 'IDENTICAL_STRUCTURE_ICON' ). "#EC NOTEXT
              lo_column->set_long_text( CONV #( text-tis ) ).
              lo_column->set_short_text( CONV #( text-tis ) ).
              lo_column->set_medium_text( CONV #( text-tis ) ).
              lo_column->set_output_length( 16 ).

            CATCH cx_root.                              "#EC NO_HANDLER
              " Erreur
              ""  --> Tant pis ...

          ENDTRY.

          TRY.
              ""  --> Modification colonne - Pas de différence de contenu
              lo_column = lo_columns->get_column( 'NO_CONTENT_DIFFERENCE' ). "#EC NOTEXT
              lo_column->set_visible( abap_false ).

            CATCH cx_root.                              "#EC NO_HANDLER
              " Erreur
              ""  --> Tant pis ...

          ENDTRY.

          TRY.
              ""  --> Modification colonne - Pas de différence de contenu
              lo_column = lo_columns->get_column( 'NO_CONTENT_DIFFERENCE_ICON' ). "#EC NOTEXT
              lo_column->set_long_text( CONV #( text-tcd ) ).
              lo_column->set_short_text( CONV #( text-tcd ) ).
              lo_column->set_medium_text( CONV #( text-tcd ) ).
              lo_column->set_output_length( 18 ).

            CATCH cx_root.                              "#EC NO_HANDLER
              " Erreur
              ""  --> Tant pis ...

          ENDTRY.

        ENDIF.

      CATCH cx_salv_msg.
        " Erreur création ALV
        ""  --> On verra ..

    ENDTRY.

    " -----------------------------------------------------------
    " Affichage Résultat
    " -----------------------------------------------------------

    " Force la sélection sur la première ligne
    lo_de_table_list->o_salv->get_selections( )->set_selected_rows(
      VALUE #( ( 1 ) )
    ).

    " Prépare les données de comparaison de la première ligne
    me->_compare_display_feed_compare( <lfs_t_table_list>[ 1 ]-tabname ).

    " Affichage du résultat
    CALL SCREEN 3000.

  ENDMETHOD.

  METHOD _custo_display_comp_alv_set.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_column          TYPE REF TO cl_salv_column,
      lo_columns         TYPE REF TO cl_salv_columns,
      lo_ccontainer      TYPE REF TO cl_gui_custom_container,
      lo_display_element TYPE REF TO lcl_main=>ts_compare_customizing_de_tab.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
    FIELD-SYMBOLS :
        <lfs_t_table_content> TYPE STANDARD TABLE.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_container_name TYPE string.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation variable
    " -----------------------------------------------------------

    IF iv_origin EQ abap_true.
      " Origine
      ""  --> Intialisation Nom Container
      lv_container_name = 'CC_COMPARE_RESULT_ORIGIN'. ##NOTEXT

      ""  --> Raccourci
      lo_display_element = REF #(
        me->ms_work_area_private-compare-customizing-display_element_content_origin
      ).

    ELSE.
      " Cible
      ""  --> Intialisation Nom Container
      lv_container_name = 'CC_COMPARE_RESULT_TARGET'. ##NOTEXT

      ""  --> Raccourci
      lo_display_element = REF #(
        me->ms_work_area_private-compare-customizing-display_element_content_target
      ).

    ENDIF.

    IF lo_display_element->ot_display_data IS BOUND.
      " Table généré
      ""  --> Pointeur données
      ASSIGN lo_display_element->ot_display_data->* TO <lfs_t_table_content>.

    ENDIF.

    TRY.
        " -----------------------------------------------------------
        " Création Custom Container
        " -----------------------------------------------------------
        " Dans le cas du changement de table; les données
        " éléments Container & SAlV doivent être recréé
        "   ... Je n'ai pas trouvé d'autres solutions ...
        " -----------------------------------------------------------

        IF lo_display_element->o_container IS BOUND.
          " Dans le cas du rechargement de la table
          ""  --> Libère les éléments du Container
          lo_display_element->o_container->free( ).

        ENDIF.

        " Création instance Container
        CREATE OBJECT lo_ccontainer
          EXPORTING
            container_name              = CONV char30( lv_container_name )
          EXCEPTIONS
            cntl_error                  = 1
            cntl_system_error           = 2
            create_error                = 3
            lifetime_error              = 4
            lifetime_dynpro_dynpro_link = 5
            OTHERS                      = 6.
        IF sy-subrc EQ 0.
          " Move-Cast
          ""  --> Container
          lo_display_element->o_container ?= lo_ccontainer.

        ENDIF.

      CATCH cx_salv_msg.
        " Erreur création Container
        ""  --> On verra
        RETURN.

    ENDTRY.

    IF NOT <lfs_t_table_content> IS ASSIGNED.
      " Table non généré
      ""  --> Arrêt du traitement
      FREE : lo_display_element->o_salv.
      RETURN.

    ENDIF.

    TRY.
        " -----------------------------------------------------------
        " Préparation de l'instance ALV
        " -----------------------------------------------------------

        " Génération instance ALV
        cl_salv_table=>factory(
           EXPORTING
             r_container    = lo_display_element->o_container
             container_name = lv_container_name
           IMPORTING
             r_salv_table   = lo_display_element->o_salv
           CHANGING
             t_table        = <lfs_t_table_content>
         ).

      CATCH cx_salv_msg.
        " Erreur génération ALV
        ""  --> Arrêt du traitement
        RETURN.

    ENDTRY.

    " Préparation fonction disponible
    lo_display_element->o_salv->get_functions( )->set_default( abap_true ).

    " Récupération instance Colonnes
    lo_columns = lo_display_element->o_salv->get_columns( ).

    " Préparation FC
    LOOP AT it_component_descr ASSIGNING FIELD-SYMBOL(<lfs_s_component_descr>).

      TRY.
          " Récupération de la Colonne
          lo_column = lo_columns->get_column( <lfs_s_component_descr>-fieldname ).

        CATCH cx_salv_not_found.
          " Colonne non trouvée
          ""  --> Passe à l'itération suivante
          CONTINUE.

      ENDTRY.

      " Modification des propriétés des Colonnes
      lo_column->set_long_text( CONV #( <lfs_s_component_descr>-scrtext_s ) ).
      lo_column->set_short_text( CONV #( <lfs_s_component_descr>-scrtext_l ) ).
      lo_column->set_medium_text( CONV #( <lfs_s_component_descr>-scrtext_m ) ).

      " Modification des propriétés des Colonnes spécifiques
      CASE <lfs_s_component_descr>-fieldname.

        WHEN 'MANDT'.                                       "#EC NOTEXT
          " Mandant
          lo_column->set_technical( abap_true ).

        WHEN 'CLNT'.                                        "#EC NOTEXT
          " Client
          lo_column->set_technical( abap_true ).

        WHEN 'ICON'.                                        "#EC NOTEXT
          " Icône

        WHEN OTHERS.
          " Autre

      ENDCASE.

    ENDLOOP.

  ENDMETHOD.

  METHOD _custo_comp_content_read_more.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Charge les données supplémentaires
    " -----------------------------------------------------------

    " Récupére les lignes supplémentaires et comparent
    me->_customizing_compare_table(
      iv_rowcount           = iv_rowcount
      it_tabname_to_compare = VALUE #(
          ( iv_tabname )
      )
    ).

    " -----------------------------------------------------------
    " Modifie le contenu des tables
    " -----------------------------------------------------------

    " Modifie le contenu des tables
    me->_compare_display_feed_compare( iv_tabname ).

    " -----------------------------------------------------------
    " Traitement supplémentaire
    " -----------------------------------------------------------

    " Simule une action pour déclencher le PBO
    cl_gui_cfw=>set_new_ok_code( lcl_main=>mc_ucomm-common-dummy ). "#EC NOTEXT

    " Synchronisation Back & Front
    cl_gui_cfw=>flush(
      EXCEPTIONS
        cntl_error = 1
        cntl_system_error = 2
    ).
    IF sy-subrc NE 0.
      " Erreur
      ""  --> Tant pis
      CLEAR : sy-subrc.

    ENDIF.

  ENDMETHOD.

  METHOD _compare_display_feed_compare.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_component_descr  TYPE lcl_main=>tt_component_descr,
      lt_component_origin TYPE cl_abap_structdescr=>component_table,
      lt_component_target TYPE cl_abap_structdescr=>component_table.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_datadescr         TYPE REF TO cl_abap_datadescr,
      lo_de_content_target TYPE REF TO lcl_main=>ts_compare_customizing_de_tab,
      lo_de_content_origin TYPE REF TO lcl_main=>ts_compare_customizing_de_tab.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
    FIELD-SYMBOLS :
      <lfs_t_display_target> TYPE STANDARD TABLE,
      <lfs_t_display_origin> TYPE STANDARD TABLE,
      <lfs_t_content_target> TYPE STANDARD TABLE,
      <lfs_t_content_origin> TYPE STANDARD TABLE.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_data_creation_error TYPE xsdboolean.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF iv_tabname IS INITIAL.
      " Aucun nom
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Pré-Traitement
    " -----------------------------------------------------------

    " Renseigne la table courrante
    me->ms_work_area_private-compare-customizing-display_element_table_list-current_tabname
      = gv_custo_tabname = iv_tabname.

    " Raccourci syntaxique
    lo_de_content_origin = REF #( me->ms_work_area_private-compare-customizing-display_element_content_origin ).
    lo_de_content_target = REF #( me->ms_work_area_private-compare-customizing-display_element_content_target ).

    " Récupération données table
    READ TABLE me->ms_work_area_private-compare-customizing-t_compare_result
    WITH TABLE KEY tabname = iv_tabname ASSIGNING FIELD-SYMBOL(<lfs_s_compare_result>).
    IF sy-subrc NE 0.
      " Table non trouvée
      ""  --> Arrêt du traitement
      rv_subrc = 1.
      RETURN.

    ENDIF.

    " Propriété affichage bouton suivant
    me->ms_work_area_private-compare-customizing-screen_properties-btn_next_active = xsdbool(
      sy-tabix LT lines( me->ms_work_area_private-compare-customizing-t_compare_result )
    ).

    " Propriété affichage bouton précédent
    me->ms_work_area_private-compare-customizing-screen_properties-btn_previous_active = xsdbool(
      sy-tabix GT 1
    ).

    " Initialisation composant
    lt_component_descr[]  = <lfs_s_compare_result>-t_component_descr[].
    lt_component_origin[] = <lfs_s_compare_result>-t_component_origin[].
    lt_component_target[] = <lfs_s_compare_result>-t_component_target[].

    " -----------------------------------------------------------
    " Ajout éléments pour affichage
    " -----------------------------------------------------------

    " Ajout élément pour affichage résultat
    ""  --> Icône
    lo_datadescr ?= cl_abap_datadescr=>describe_by_name( 'ICON_D' ). "#EC NOTEXT
    INSERT VALUE #(
      name = 'ICON'                                         "#EC NOTEXT
      type = lo_datadescr
    ) INTO : lt_component_origin INDEX 1, lt_component_target INDEX 1.

    ""  --> Description
    INSERT VALUE #(
      fieldname = 'ICON'                                    "#EC NOTEXT
      scrtext_s = CONV #( text-tic )
      scrtext_m = CONV #( text-tic )
      scrtext_l = CONV #( text-tic )
    ) INTO TABLE lt_component_descr.

    " -----------------------------------------------------------
    " Création table d'affichage
    " -----------------------------------------------------------

    IF <lfs_s_compare_result>-exist_in_origin EQ abap_true.
      " Génération table de données d'Origine
      lv_data_creation_error = me->_custo_compare_generate_table(
        EXPORTING
          it_component = lt_component_origin
        IMPORTING
          eot_table    = lo_de_content_origin->ot_display_data
      ).

      " Initialisation pointeur
      ASSIGN lo_de_content_origin->ot_display_data->* TO <lfs_t_display_origin>.

    ELSE.
      " Table n'existe pas dans système d'origine
      ""  --> Destruction des données à afficher
      CLEAR : lo_de_content_origin->ot_display_data.

    ENDIF.

    IF  lv_data_creation_error EQ abap_false
    AND <lfs_s_compare_result>-exist_in_target EQ abap_true.
      " Génération table de données Cible
      lv_data_creation_error = me->_custo_compare_generate_table(
        EXPORTING
          it_component = lt_component_target
        IMPORTING
          eot_table    = lo_de_content_target->ot_display_data
      ).

      " Initialisation pointeur
      ASSIGN lo_de_content_target->ot_display_data->* TO <lfs_t_display_target>.

    ELSE.
      " Table n'existe pas dans système cible
      ""  --> Destruction des données à afficher
      CLEAR : lo_de_content_target->ot_display_data.

    ENDIF.

    " Initialisation pointeur
    ASSIGN <lfs_s_compare_result>-ot_content_target->* TO <lfs_t_content_target>.
    ASSIGN <lfs_s_compare_result>-ot_content_origin->* TO <lfs_t_content_origin>.

    " -----------------------------------------------------------
    " Alimentation table d'affichage résultat
    " -----------------------------------------------------------

    " Alimentation table Cible
    IF  <lfs_t_content_target> IS ASSIGNED
    AND <lfs_t_content_origin> IS ASSIGNED
    AND <lfs_s_compare_result>-exist_in_origin EQ abap_true
    AND <lfs_s_compare_result>-exist_in_target EQ abap_true.
      " Utilise aussi la table de contenu d'Origine
      me->_custo_display_fill_content(
        EXPORTING
          it_content_to_use     = <lfs_t_content_target>
          it_content_to_compare = <lfs_t_content_origin>
        IMPORTING
          et_display_data       = <lfs_t_display_target>
      ).

    ELSEIF <lfs_t_content_target> IS ASSIGNED
       AND <lfs_s_compare_result>-exist_in_target EQ abap_true.
      " Sans utiliser la table de contenu d'Origine
      me->_custo_display_fill_content(
        EXPORTING
          it_content_to_use = <lfs_t_content_target>
        IMPORTING
          et_display_data   = <lfs_t_display_target>
      ).

    ENDIF.

    " Alimentation table Origine
    IF  <lfs_t_content_origin> IS ASSIGNED
    AND <lfs_t_content_target> IS ASSIGNED
    AND <lfs_s_compare_result>-exist_in_origin EQ abap_true
    AND <lfs_s_compare_result>-exist_in_target EQ abap_true.
      " Utilise aussi la table de contenu Cible
      me->_custo_display_fill_content(
        EXPORTING
          it_content_to_use     = <lfs_t_content_origin>
          it_content_to_compare = <lfs_t_content_target>
        IMPORTING
          et_display_data       = <lfs_t_display_origin>
      ).

    ELSEIF <lfs_t_content_origin> IS ASSIGNED
       AND <lfs_s_compare_result>-exist_in_origin EQ abap_true.
      " Sans utiliser la table de contenu Cible
      me->_custo_display_fill_content(
        EXPORTING
          it_content_to_use = <lfs_t_content_origin>
        IMPORTING
          et_display_data   = <lfs_t_display_origin>
      ).

    ENDIF.

    " -----------------------------------------------------------
    " Création table d'affichage
    " -----------------------------------------------------------

    " Création de l'ALV Cible
    rv_subrc = me->_custo_display_comp_alv_set(
      iv_origin          = abap_false
      it_component       = <lfs_s_compare_result>-t_component_target
      it_component_descr = <lfs_s_compare_result>-t_component_descr
    ).

    IF rv_subrc IS INITIAL.
      " Création de l'ALV Origine
      rv_subrc = me->_custo_display_comp_alv_set(
          iv_origin          = abap_true
          it_component       = <lfs_s_compare_result>-t_component_origin
          it_component_descr = <lfs_s_compare_result>-t_component_descr
        ).

    ENDIF.
    IF NOT rv_subrc IS INITIAL.
      " Erreur
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Changement texte détail
    " -----------------------------------------------------------

    " Origine - Détail
    me->ms_work_area_private-compare-system-detail_origin->* = me->ms_work_area_private-compare-system-origin->*.
    IF <lfs_t_display_origin> IS ASSIGNED.
      me->ms_work_area_private-compare-system-detail_origin->* =
      |{ me->ms_work_area_private-compare-system-detail_origin->* }| &&
      | \| { lines( <lfs_t_display_origin> ) } \\ { <lfs_s_compare_result>-lines_count_origin } { text-tnl }|.

    ENDIF.

    " Cible - Détail
    me->ms_work_area_private-compare-system-detail_target->* = me->ms_work_area_private-compare-system-target->*.
    IF <lfs_t_display_target> IS ASSIGNED.
      me->ms_work_area_private-compare-system-detail_target->* =
        |{ me->ms_work_area_private-compare-system-detail_target->* }| &&
        | \| { lines( <lfs_t_display_target> ) } \\ { <lfs_s_compare_result>-lines_count_target } { text-tnl }|.

    ENDIF.

  ENDMETHOD.

  METHOD _custo_display_fill_content.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
    FIELD-SYMBOLS :
      <lfs_field> TYPE any.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_icon TYPE string.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    REFRESH : et_display_data.

    " -----------------------------------------------------------
    " Alimentation données à afficher
    " -----------------------------------------------------------

    " Alimentation données Origne
    LOOP AT it_content_to_use ASSIGNING FIELD-SYMBOL(<lfs_s_content>).

      " Ajout de l'entrée
      APPEND INITIAL LINE TO et_display_data
                   ASSIGNING FIELD-SYMBOL(<lfs_s_display>).

      " Initialisation données communes
      MOVE-CORRESPONDING <lfs_s_content> TO <lfs_s_display>.

      IF me->ms_selection_criteria-compare_option-ov_only_difference->* EQ abap_true.
        " Affichage uniquement des divergences
        ""  --> Initialisation icône en erreur
        lv_icon = text-e00.

      ELSE.
        "  Affichage de toutes les entrées
        READ TABLE it_content_to_compare WITH KEY table_line = <lfs_s_content> TRANSPORTING NO FIELDS.
        IF sy-subrc EQ 0.
          " L'entrée existe
          ""  --> Initialisation indicateur OK
          lv_icon = text-s00.

        ELSE.
          " L'entrée n'existe pas dans le système cible
          ""  --> Initialisation indicateur en erreur
          lv_icon = text-e00.

        ENDIF.

      ENDIF.

      IF NOT lv_icon IS INITIAL.
        " Initialisation indicateur
        ASSIGN COMPONENT 'ICON' OF STRUCTURE <lfs_s_display> "#EC NOTEXT
                                          TO <lfs_field>.
        IF sy-subrc EQ 0.
          " Correspondance trouvée
          ""  --> Initialisation icône
          <lfs_field> = lv_icon.

        ENDIF.

      ENDIF.

      " Réinitialisation
      CLEAR    : lv_icon.
      UNASSIGN : <lfs_field>.

    ENDLOOP.

  ENDMETHOD.

  METHOD _custo_compare_content_table.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_tabledescr  TYPE REF TO cl_abap_tabledescr,
      lo_structdescr TYPE REF TO cl_abap_structdescr.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_data_creation_error TYPE xsdboolean.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
    FIELD-SYMBOLS :
      <lfs_t_table_origin> TYPE STANDARD TABLE,
      <lfs_t_table_target> TYPE STANDARD TABLE.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Récupération table résultat
    " -----------------------------------------------------------

    " Récupération de l'entrée dans table de résultat
    READ TABLE me->ms_work_area_private-compare-customizing-t_compare_result
    WITH TABLE KEY tabname = iv_tablename
         ASSIGNING FIELD-SYMBOL(<lfs_s_compare_result>).
    IF sy-subrc NE 0. "Ne devrait pas arriver
      " Création de l'entrée
      INSERT VALUE #(
        tabname         = iv_tablename
        exist_in_origin = xsdbool( NOT it_fields_origin[] IS INITIAL )
        exist_in_target = xsdbool( NOT it_fields_target[] IS INITIAL )
      ) INTO TABLE me->ms_work_area_private-compare-customizing-t_compare_result
         ASSIGNING <lfs_s_compare_result>.

    ENDIF.

    " Structure identique ?
    <lfs_s_compare_result>-identical_structure = xsdbool(
      it_fields_origin[] = it_fields_target[]
    ).

    " -----------------------------------------------------------
    " Constitution structure de comparaison
    " -----------------------------------------------------------

    IF  <lfs_s_compare_result>-identical_structure EQ abap_false
    AND me->ms_selection_criteria-compare_option-ov_compare_identical_struct->* EQ abap_false.
      " Les champs ne sont pas identiques et on compare chaque structure séparemment
      IF <lfs_s_compare_result>-exist_in_origin EQ abap_true.
        ""  --> Construction de la structure d'Origine
        me->_custo_compare_prepare_struct(
          EXPORTING
            it_fields_to_use   = it_fields_origin
          IMPORTING
            et_component       = <lfs_s_compare_result>-t_component_origin
          CHANGING
            ct_component_descr = <lfs_s_compare_result>-t_component_descr
        ).

      ENDIF.

      IF <lfs_s_compare_result>-exist_in_target EQ abap_true.
        ""  --> Construction de la structure Cible
        me->_custo_compare_prepare_struct(
          EXPORTING
            it_fields_to_use   = it_fields_target
          IMPORTING
            et_component       = <lfs_s_compare_result>-t_component_target
          CHANGING
            ct_component_descr = <lfs_s_compare_result>-t_component_descr
        ).

      ENDIF.

    ELSE.
      " Les champs sont identiques ou on compare à structure identique
      ""  --> Construction de la structure commune
      IF <lfs_s_compare_result>-exist_in_origin EQ abap_true
      OR <lfs_s_compare_result>-exist_in_target EQ abap_true.
        " Existe au moins dans l'un des systèmes
        IF <lfs_s_compare_result>-exist_in_origin EQ abap_true.
          " On se base sur le système d'origine
          me->_custo_compare_prepare_struct(
            EXPORTING
              it_fields_to_use       = it_fields_origin
              it_fields_to_compare   = it_fields_target
              iv_identical_structure = <lfs_s_compare_result>-identical_structure
            IMPORTING
              et_component           = <lfs_s_compare_result>-t_component_origin
            CHANGING
              ct_component_descr     = <lfs_s_compare_result>-t_component_descr
          ).

        ELSE.
          " On se base sur le système cible
          me->_custo_compare_prepare_struct(
            EXPORTING
              it_fields_to_use       = it_fields_target
              it_fields_to_compare   = it_fields_origin
              iv_identical_structure = <lfs_s_compare_result>-identical_structure
            IMPORTING
              et_component           = <lfs_s_compare_result>-t_component_target
            CHANGING
              ct_component_descr     = <lfs_s_compare_result>-t_component_descr
          ).

        ENDIF.

      ENDIF.

      ""  --> Utilise la même struture pour la cible
      <lfs_s_compare_result>-t_component_target[] = <lfs_s_compare_result>-t_component_origin.

    ENDIF.

    IF  <lfs_s_compare_result>-t_component_origin[] IS INITIAL
    AND <lfs_s_compare_result>-t_component_target[] IS INITIAL.
      " Aucun champ en commun // table inexistante dans les deux systèmes
      ""  --> Initialisation indicateur aucun champ
      <lfs_s_compare_result>-no_common_fields = abap_true.

      ""  --> Arrêt du traitement
      MESSAGE ID 'ZTOOLS' TYPE if_msg_output=>msgtype_error "#EC NOTEXT
          NUMBER 012      INTO <lfs_s_compare_result>-message.
      RETURN.

    ENDIF.

    " Récupération description des champs
    ""  // Et si les champs n'existent pas dans le sysètem courant ? Bah tant pis ...
    SELECT fieldname, scrtext_s, scrtext_m, scrtext_l
      FROM dd03vt
      FOR ALL ENTRIES IN @<lfs_s_compare_result>-t_component_descr
            WHERE tabname    EQ @iv_tablename
              AND fieldname  EQ @<lfs_s_compare_result>-t_component_descr-fieldname
              AND ddlanguage EQ @sy-langu
       INTO TABLE @<lfs_s_compare_result>-t_component_descr.

    " -----------------------------------------------------------
    " Création table Origine
    " -----------------------------------------------------------

    IF <lfs_s_compare_result>-exist_in_origin EQ abap_true.
      " Création de la table
      lv_data_creation_error = me->_custo_compare_generate_table(
        EXPORTING
          it_component = <lfs_s_compare_result>-t_component_origin
        IMPORTING
          eot_table    = <lfs_s_compare_result>-ot_content_origin
      ).

    ELSE.
      " Création de la table avec structure plate
      CREATE DATA <lfs_s_compare_result>-ot_content_origin TYPE esh_t_co_rfcrt_data.

    ENDIF.

    IF  lv_data_creation_error EQ abap_false
    AND <lfs_s_compare_result>-exist_in_target EQ abap_true.
      " -----------------------------------------------------------
      " Création table Cible
      " -----------------------------------------------------------

      " Création de la table
      lv_data_creation_error = me->_custo_compare_generate_table(
        EXPORTING
          it_component = <lfs_s_compare_result>-t_component_target
        IMPORTING
          eot_table    = <lfs_s_compare_result>-ot_content_target
      ).

    ELSE.
      " Création de la table avec structure plate
      CREATE DATA <lfs_s_compare_result>-ot_content_target TYPE esh_t_co_rfcrt_data.

    ENDIF.

    IF lv_data_creation_error EQ abap_true.
      " Erreur création d'une des tables
      ""  --> Création table type générique
      CREATE DATA <lfs_s_compare_result>-ot_content_origin TYPE esh_t_co_rfcrt_data.
      CREATE DATA <lfs_s_compare_result>-ot_content_target TYPE esh_t_co_rfcrt_data.

      ""  --> Récupération composant
      " Création type handle sur structure de résultat
      lo_tabledescr ?= cl_abap_tabledescr=>describe_by_data_ref( <lfs_s_compare_result>-ot_content_target ).

      " Récupération structure de la table
      lo_structdescr ?= lo_tabledescr->get_table_line_type( ).

      " Récupération Composant
      <lfs_s_compare_result>-t_component_origin =
        <lfs_s_compare_result>-t_component_target = lo_structdescr->get_components( ).

      " Change les champs de description
      <lfs_s_compare_result>-t_component_descr = VALUE #(
        (
          fieldname = 'WA'                                  "#EC NOTEXT
          scrtext_s = 'Données'                             "#EC NOTEXT
          scrtext_m = 'Données'                             "#EC NOTEXT
          scrtext_l = 'Données'                             "#EC NOTEXT
        )
      ).

    ENDIF.

    IF NOT <lfs_s_compare_result>-ot_content_origin IS BOUND
    OR NOT <lfs_s_compare_result>-ot_content_target IS BOUND.
      " Erreur lors de la génération des tables de Custo
      ""  --> Arrêt du traitement
      <lfs_s_compare_result>-compare_error = abap_true.
      MESSAGE ID 'ZTOOLS' TYPE if_msg_output=>msgtype_error "#EC NOTEXT
          NUMBER 013      INTO <lfs_s_compare_result>-message.
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Initialisation données - Origine
    " -----------------------------------------------------------

    " Initialisation pointeur table origine
    ASSIGN <lfs_s_compare_result>-ot_content_origin->* TO <lfs_t_table_origin>.
    IF sy-subrc EQ 0.
      ""  --> Intiailisation pointeur table cible
      ASSIGN <lfs_s_compare_result>-ot_content_target->* TO <lfs_t_table_target>.

    ENDIF.
    IF sy-subrc NE 0.
      " Erreur lors de l'attribution du FS sur table de custo
      ""  --> Arrêt du traitement
      <lfs_s_compare_result>-compare_error = abap_true.
      MESSAGE ID 'ZTOOLS' TYPE if_msg_output=>msgtype_error "#EC NOTEXT
          NUMBER 013      INTO <lfs_s_compare_result>-message.
      RETURN.

    ENDIF.

    " Alimentation de la table d'Origine
    IF lv_data_creation_error EQ abap_true
    OR <lfs_s_compare_result>-identical_structure EQ abap_true.
      " Erreur création type structuré ou Structure identique
      ""  --> On pousse simplement les lignes
      <lfs_t_table_origin> = it_data_origin[].
      <lfs_t_table_target> = it_data_target[].

    ELSE.
      " Structure divergente
      ""  --> On pousse les élèments en commun entre les deux types
      IF <lfs_s_compare_result>-exist_in_origin EQ abap_true.
        " Table contenu cible
        me->_custo_comp_content_table_set(
          EXPORTING
            it_fields        = it_fields_origin
            it_component     = <lfs_s_compare_result>-t_component_origin
            it_table_content = it_data_origin
          IMPORTING
            et_data_export   = <lfs_t_table_origin>
        ).

      ENDIF.

      IF <lfs_s_compare_result>-exist_in_target EQ abap_true.
        ""  --> Même traitement pour le système cible
        me->_custo_comp_content_table_set(
          EXPORTING
            it_fields        = it_fields_target
            it_component     = <lfs_s_compare_result>-t_component_target
            it_table_content = it_data_target
          IMPORTING
            et_data_export   = <lfs_t_table_target>
        ).

      ENDIF.

    ENDIF.

    " Tri
    SORT : <lfs_t_table_target>, <lfs_t_table_origin>.

    " Données identiques ?
    IF <lfs_s_compare_result>-lines_count_origin NE <lfs_s_compare_result>-lines_count_target.
      " Nombre de lignes différentes
      <lfs_s_compare_result>-no_content_difference = abap_false.

    ELSEIF lines( <lfs_t_table_origin> ) NE <lfs_s_compare_result>-lines_count_origin
        OR lines( <lfs_t_table_target> ) NE <lfs_s_compare_result>-lines_count_target.
      " Toutes les lignes non pas été chargées
      ""  --> Différenciation impossible
      <lfs_s_compare_result>-no_content_difference = abap_undefined.

    ELSE.
      " Toutes les lignes chargées
      <lfs_s_compare_result>-no_content_difference = xsdbool(
        <lfs_t_table_origin>[] EQ <lfs_t_table_target>[]
        AND <lfs_s_compare_result>-exist_in_origin EQ abap_true
        AND <lfs_s_compare_result>-exist_in_target EQ abap_true
      ).

    ENDIF.

    " -----------------------------------------------------------
    " Traitement optionnel
    " -----------------------------------------------------------

    " Conserve uniquement les données différentes ?
    IF  <lfs_s_compare_result>-no_content_difference                   EQ abap_false
    AND me->ms_selection_criteria-compare_option-ov_only_difference->* EQ abap_true.
      " Il y a au moins une différence
      ""  --> Compare la source à la cible
      LOOP AT <lfs_t_table_origin> ASSIGNING FIELD-SYMBOL(<lfs_s_table_origin>).

        " La ligne existe-t-elle dans le système cible ?
        READ TABLE <lfs_t_table_target> WITH KEY table_line = <lfs_s_table_origin>
                                    TRANSPORTING NO FIELDS.
        IF sy-subrc NE 0.
          " La ligne n'existe pas
          ""  --> Conserve la ligne // Passe à l'itération suivante
          CONTINUE.

        ENDIF.

        " La ligne existe
        ""  --> Supprime la ligne dans la table cible
        DELETE <lfs_t_table_target> INDEX sy-tabix.

        ""  --> Supprime la ligne dans la table d'origine
        DELETE <lfs_t_table_origin> USING KEY loop_key.
        CONTINUE.

      ENDLOOP.

      ""  --> Compare la cible à la source
      LOOP AT <lfs_t_table_target> ASSIGNING FIELD-SYMBOL(<lfs_s_table_target>).

        " La ligne existe-t-elle dans le système d'origine ?
        READ TABLE <lfs_t_table_origin> WITH KEY table_line = <lfs_s_table_target>
                                    TRANSPORTING NO FIELDS.
        IF sy-subrc NE 0.
          " La ligne n'existe pas
          ""  --> Conserve la ligne // Passe à l'itération suivante
          CONTINUE.

        ENDIF.

        " La ligne existe
        ""  --> Supprime la ligne dans la table cible
        DELETE <lfs_t_table_origin> INDEX sy-tabix.

        ""  --> Supprime la ligne dans la table d'origine
        DELETE <lfs_t_table_target> USING KEY loop_key.
        CONTINUE.

      ENDLOOP.

    ENDIF.

    " -----------------------------------------------------------
    " Conclusion
    " -----------------------------------------------------------

    " Au moins une table avec des différences ?
    READ TABLE me->ms_work_area_private-compare-customizing-t_compare_result
      WITH KEY no_content_difference = abap_false TRANSPORTING NO FIELDS.
    IF sy-subrc NE 0.
      " Aucune différence dans les systèmes
      ""  --> Affiche message succès
      MESSAGE s036(e2).
      RETURN.

    ENDIF.

  ENDMETHOD.

  METHOD _custo_compare_prepare_struct.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_fieldname TYPE REF TO data.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
          ls_component TYPE cl_abap_structdescr=>component.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    REFRESH : et_component.

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF it_fields_to_use[] IS INITIAL.
      " Aucun champ
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Initialisation table des champs à afficher
    " -----------------------------------------------------------

    " Constitution des champs de la table
    LOOP AT it_fields_to_use ASSIGNING FIELD-SYMBOL(<lfs_s_fields_to_use>).

      CLEAR : lo_fieldname.

      IF it_fields_to_compare    IS SUPPLIED
      AND iv_identical_structure EQ abap_false.
        " Table des champs transmises et structure divergentes
        "" --> Vérifie l'existence du Champ
        READ TABLE it_fields_to_compare
          WITH KEY fieldname = <lfs_s_fields_to_use>-fieldname
          TRANSPORTING NO FIELDS.
        IF sy-subrc NE 0
        AND me->ms_selection_criteria-compare_option-ov_compare_identical_struct->* EQ abap_true.
          " Champ inexistant et uniquement comparaison structure identique
          ""  --> Passe à l'itération suivante
          CONTINUE.

        ENDIF.

      ENDIF.

      TRY.
          " Création élément de données (on force en type C pour éviter des DUMPs)
          CREATE DATA lo_fieldname TYPE c
                                 LENGTH <lfs_s_fields_to_use>-length.
          IF sy-subrc NE 0
          OR NOT lo_fieldname IS BOUND.
            " Erreur création
            ""  --> Passe à l'itération suivante
            CONTINUE.

          ENDIF.

          " Initialisation
          ls_component-name  = <lfs_s_fields_to_use>-fieldname.
          ls_component-type ?= cl_abap_datadescr=>describe_by_data_ref( lo_fieldname ).

        CATCH cx_root.
          " Erreur création du champ
          ""  --> Passe à l'itération suivante
          CONTINUE.

      ENDTRY.

      " Ajout dans table de composant
      APPEND ls_component TO et_component.

      " Ajout dans la table pour récupération description
      READ TABLE ct_component_descr WITH TABLE KEY fieldname = <lfs_s_fields_to_use>-fieldname
                                      TRANSPORTING NO FIELDS.
      IF sy-subrc NE 0.
        INSERT VALUE #(
          fieldname = <lfs_s_fields_to_use>-fieldname
        ) INTO TABLE ct_component_descr.

      ENDIF.

    ENDLOOP.

  ENDMETHOD.

  METHOD _custo_compare_generate_table.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_table       TYPE REF TO data,
      lo_datadescr   TYPE REF TO cl_abap_datadescr,
      lo_line_type   TYPE REF TO cl_abap_datadescr,
      lo_tabledescr  TYPE REF TO cl_abap_tabledescr,
      lo_structdescr TYPE REF TO cl_abap_structdescr.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    TRY.
        " -----------------------------------------------------------
        " Création table
        " -----------------------------------------------------------

        " Création type handle structure
        lo_structdescr ?= cl_abap_structdescr=>create( it_component ).

        " Création type handle table
        lo_line_type ?= lo_structdescr.
        lo_tabledescr = cl_abap_tabledescr=>create( lo_line_type ).

        " Création table
        CREATE DATA eot_table TYPE HANDLE lo_tabledescr.
        IF sy-subrc NE 0.
          " Erreur création
          ""  --> Initialisation témoin erreur création
          rv_data_creation_error = abap_true.

          ""  --> Arrêt du traitement
          RETURN.

        ENDIF.

      CATCH cx_sy_struct_creation.
        " Erreur création structure
        ""  --> Initialisation témoin erreur création
        rv_data_creation_error = abap_true.

        ""  --> Arrêt du traitement
        RETURN.

      CATCH cx_sy_table_creation.
        " Erreur création table
        ""  --> Initialisation témoin erreur création
        rv_data_creation_error = abap_true.

        ""  --> Arrêt du traitement
        RETURN.

      CATCH cx_root.
        " Erreur
        ""  --> Initialisation témoin erreur création
        rv_data_creation_error = abap_true.

        ""  --> Arrêt du traitement
        RETURN.

    ENDTRY.

  ENDMETHOD.

  METHOD _custo_comp_content_table_set.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
    FIELD-SYMBOLS :
      <lfs_value_data_filled>  TYPE any,
      <lfs_value_data_to_fill> TYPE any.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    REFRESH : et_data_export.

    " -----------------------------------------------------------
    " Initialisation table de sortie
    " -----------------------------------------------------------

    " Parcours le contenu de la table
    LOOP AT it_table_content ASSIGNING FIELD-SYMBOL(<lfs_s_table_content>).

      " Création nouvelle ligne de donnée
      APPEND INITIAL LINE TO et_data_export ASSIGNING FIELD-SYMBOL(<lfs_s_data_export>).

      " Parcours chaque Champ commun
      LOOP AT it_component ASSIGNING FIELD-SYMBOL(<lfs_s_component>).

        " Récupération donnée de ce champ
        READ TABLE it_fields
          WITH KEY fieldname = <lfs_s_component>-name
         ASSIGNING FIELD-SYMBOL(<lfs_s_fields>).
        IF sy-subrc NE 0. "Ne devrait pas se produire
          " Aucune correspondance
          ""  --> Passe à l'itération suivante
          CONTINUE.

        ENDIF.

        " Initialisation pointeur sur le champ
        ASSIGN <lfs_s_table_content>+<lfs_s_fields>-offset(<lfs_s_fields>-length)
            TO <lfs_value_data_filled>.
        IF sy-subrc EQ 0 AND NOT <lfs_value_data_filled> IS INITIAL.
          " Initialisation pointeur sur le champ d'export
          ASSIGN COMPONENT <lfs_s_component>-name
              OF STRUCTURE <lfs_s_data_export>
                        TO <lfs_value_data_to_fill>.

        ENDIF.
        IF NOT <lfs_value_data_to_fill> IS ASSIGNED.
          " Aucune correspondance // Pas de valeur
          ""  --> Passe à l'itération suivante
          CONTINUE.

        ENDIF.

        " Initialisation valeur du champ
        <lfs_value_data_to_fill> = <lfs_value_data_filled>.

        UNASSIGN : <lfs_value_data_to_fill>, <lfs_value_data_filled>.

      ENDLOOP.

    ENDLOOP.

  ENDMETHOD.

  METHOD _workbench_result_save.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

*    TRY.
*        " -----------------------------------------------------------
*        " Sauvegarde le résultat
*        " -----------------------------------------------------------
*
*        " Sauvegarde les données de résultat
*        zcl_archive=>archive_add(
*            ix_data                = REF #( me->ms_work_area_private-compare-workbench-display_element-t_display_data[] )
*            iv_archive_type        = lcl_main=>mc_archive_type
*            iv_object_id_component = 'UNAME'                "#EC NOTEXT
*            iv_compression         = abap_true
*        ).
*
*      CATCH zcx_archive.
*
*    ENDTRY.

  ENDMETHOD.

  METHOD progress_display.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_text TYPE string.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation texte
    " -----------------------------------------------------------

    IF NOT iv_text IS INITIAL.
      " Texte transmis
      ""  --> Utilisation de ce texte
      lv_text = iv_text.

    ELSEIF NOT iv_msgid IS INITIAL
       AND NOT iv_msgno IS INITIAL.
      " Classe de message transmise
      ""  --> Utilisation de ce message
      MESSAGE ID iv_msgid TYPE if_msg_output=>msgtype_success
          NUMBER iv_msgno WITH iv_msgv1 iv_msgv2 iv_msgv3 iv_msgv3
            INTO lv_text.

    ELSE.
      " Pas suffisamment de paramètre
      ""  --> Utilisation texte par défaut
      lv_text = text-p01.

    ENDIF.

    " -----------------------------------------------------------
    " Affichage de la barre de progression
    " -----------------------------------------------------------

    CALL FUNCTION 'SAPGUI_PROGRESS_INDICATOR'
      EXPORTING
        text       = iv_text
        percentage = iv_percentage.

  ENDMETHOD.

  METHOD range_2_where.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_where_clauses TYPE rsds_twhere.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF ir_selopt_t[] IS INITIAL.
      " Aucune condition
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Sélection des données
    " -----------------------------------------------------------

    " Range vers Chaîne de caractère
    CALL FUNCTION 'FREE_SELECTIONS_RANGE_2_WHERE'
      EXPORTING
        field_ranges  = VALUE rsds_trange(
                          (
                            tablename = iv_tablename
                            frange_t  = VALUE #(
                                          (
                                            fieldname = iv_fieldname
                                            selopt_t  = ir_selopt_t
                                           )
                                         )
                          )
                        )
      IMPORTING
        where_clauses = lt_where_clauses.

    IF lt_where_clauses[] IS INITIAL.
      " Aucune condition
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Concaténation
    " -----------------------------------------------------------

    " Parcours l'ensemble des conditions
    LOOP AT lt_where_clauses[ 1 ]-where_tab ASSIGNING FIELD-SYMBOL(<lfs_s_where_tab>).

      " Concaténation de la chaîne de caractère
      rv_sql_where = |{ rv_sql_where } { <lfs_s_where_tab>-line }|.

    ENDLOOP.

  ENDMETHOD.

ENDCLASS.

*---------------------------------------------------------------------*
*       CLASS lcl_customizing_handle_events IMPLEMENTATION
*---------------------------------------------------------------------*
*
*---------------------------------------------------------------------*
CLASS lcl_customizing_handle_events IMPLEMENTATION.

  METHOD constructor.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation attributs
    " -----------------------------------------------------------

    " Instance principale
    me->mo_main = io_main.

    " ID de l'ALV
    me->mv_salv_id = iv_salv_id.

    " Grille ALV
    me->mo_salv_table = io_salv_table.

  ENDMETHOD.

  METHOD on_link_click.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_method TYPE string.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

    TRY.
        " -----------------------------------------------------------
        " Oriente le traitement en fonction de l'ID de l'ALV
        " -----------------------------------------------------------

        " Initialisation du Nom de la méthode
        lv_method = |_ON_LINK_CLICK_{ me->mv_salv_id }|. "#EC NOTEXT   "#EC NOTEXT

        " Appel de la méthode
        CALL METHOD me->(lv_method)
          EXPORTING
            iv_row    = row
            iv_column = column.

      CATCH cx_root.
        " Erreur lors de l'appel de la méthode
        ""  --> Arrêt du traitement
        RETURN.

    ENDTRY.

  ENDMETHOD.

  METHOD on_double_click.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_method TYPE string.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

    TRY.
        " -----------------------------------------------------------
        " Oriente le traitement en fonction de l'ID de l'ALV
        " -----------------------------------------------------------

        " Initialisation du Nom de la méthode
        lv_method = |_ON_DOUBLE_CLICK_{ me->mv_salv_id }|. "#EC NOTEXT   "#EC NOTEXT

        " Appel de la méthode
        CALL METHOD me->(lv_method)
          EXPORTING
            iv_row    = row
            iv_column = column.

      CATCH cx_root.
        " Erreur lors de l'appel de la méthode
        ""  --> Arrêt du traitement
        RETURN.

    ENDTRY.

  ENDMETHOD.

  METHOD _on_link_click_custo_tl.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

    " -----------------------------------------------------------
    " Suivant le lien sélectionné
    " -----------------------------------------------------------

    " Suivant la Colonne
    CASE iv_column.

      WHEN 'DISPLAY_ICON'.                                  "#EC NOTEXT
        " Affichage
        ""  --> Force la sélection de la ligne
        me->mo_salv_table->get_selections( )->set_selected_rows(
          VALUE #( ( iv_row ) )
        ).

        ""  --> Modifie les données affichées
        me->mo_main->customizing_on_change_line( iv_row = iv_row ).

      WHEN OTHERS.
        " Autre
        ""  --> Arrêt du traitement
        RETURN.

    ENDCASE.

  ENDMETHOD.                    "_on_link_click_custo_tl

  METHOD _on_double_click_custo_tl.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

    " -----------------------------------------------------------
    " Suivant l'élément
    " -----------------------------------------------------------

    " Modifie les données affichées
    me->mo_main->customizing_on_change_line( iv_row = iv_row ).

    " Suivant la Colonne
    CASE iv_column.

      WHEN 'TABNAME'.                                       "#EC NOTEXT
        " Nom de la table
        ""  --> Ouvre la transaction SE11
        me->mo_main->ddic_transaction_display_table( iv_row ).

      WHEN OTHERS.

    ENDCASE.

  ENDMETHOD.                    "_on_double_click_custo_tl

ENDCLASS.                    "lcl_customizing_handle_events IMPLEMENTATION
